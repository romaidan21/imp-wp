/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.5-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: imp
-- ------------------------------------------------------
-- Server version	11.8.5-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `bb_commentmeta`
--

DROP TABLE IF EXISTS `bb_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_commentmeta`
--

LOCK TABLES `bb_commentmeta` WRITE;
/*!40000 ALTER TABLE `bb_commentmeta` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bb_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_comments`
--

DROP TABLE IF EXISTS `bb_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_comments`
--

LOCK TABLES `bb_comments` WRITE;
/*!40000 ALTER TABLE `bb_comments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bb_comments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_links`
--

DROP TABLE IF EXISTS `bb_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_links`
--

LOCK TABLES `bb_links` WRITE;
/*!40000 ALTER TABLE `bb_links` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bb_links` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_options`
--

DROP TABLE IF EXISTS `bb_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=696 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_options`
--

LOCK TABLES `bb_options` WRITE;
/*!40000 ALTER TABLE `bb_options` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_options` VALUES
(1,'cron','a:12:{i:1774433731;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1774458931;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1774461803;a:1:{s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1774461885;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1774461892;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1774462530;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1774464330;a:1:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1774466130;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1774893927;a:1:{s:30:\"wp_delete_temp_updater_backups\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1774953112;a:1:{s:27:\"acf_update_site_health_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1774977331;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}','on'),
(2,'siteurl','http://imp.loc/','on'),
(3,'home','http://imp.loc/','on'),
(4,'blogname','Адвокатське Бюро «Ігор Мельник та Партнери»','on'),
(5,'blogdescription','','on'),
(6,'users_can_register','0','on'),
(7,'admin_email','romecom2210@gmail.com','on'),
(8,'start_of_week','1','on'),
(9,'use_balanceTags','0','on'),
(10,'use_smilies','1','on'),
(11,'require_name_email','1','on'),
(12,'comments_notify','1','on'),
(13,'posts_per_rss','10','on'),
(14,'rss_use_excerpt','0','on'),
(15,'mailserver_url','mail.example.com','on'),
(16,'mailserver_login','login@example.com','on'),
(17,'mailserver_pass','','on'),
(18,'mailserver_port','110','on'),
(19,'default_category','1','on'),
(20,'default_comment_status','open','on'),
(21,'default_ping_status','open','on'),
(22,'default_pingback_flag','1','on'),
(23,'posts_per_page','10','on'),
(24,'date_format','F j, Y','on'),
(25,'time_format','g:i a','on'),
(26,'links_updated_date_format','F j, Y g:i a','on'),
(27,'comment_moderation','0','on'),
(28,'moderation_notify','1','on'),
(29,'permalink_structure','/%postname%/','on'),
(30,'rewrite_rules','a:147:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:22:\"^blog/category/(.+)/?$\";s:35:\"index.php?blog_category=$matches[1]\";s:7:\"blog/?$\";s:24:\"index.php?post_type=blog\";s:37:\"blog/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=blog&feed=$matches[1]\";s:32:\"blog/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=blog&feed=$matches[1]\";s:24:\"blog/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=blog&paged=$matches[1]\";s:11:\"services/?$\";s:28:\"index.php?post_type=services\";s:41:\"services/feed/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?post_type=services&feed=$matches[1]\";s:36:\"services/(feed|rdf|rss|rss2|atom)/?$\";s:45:\"index.php?post_type=services&feed=$matches[1]\";s:28:\"services/page/([0-9]{1,})/?$\";s:46:\"index.php?post_type=services&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:32:\"blog/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"blog/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"blog/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"blog/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"blog/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"blog/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"blog/([^/]+)/embed/?$\";s:37:\"index.php?blog=$matches[1]&embed=true\";s:25:\"blog/([^/]+)/trackback/?$\";s:31:\"index.php?blog=$matches[1]&tb=1\";s:45:\"blog/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?blog=$matches[1]&feed=$matches[2]\";s:40:\"blog/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?blog=$matches[1]&feed=$matches[2]\";s:33:\"blog/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?blog=$matches[1]&paged=$matches[2]\";s:40:\"blog/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?blog=$matches[1]&cpage=$matches[2]\";s:29:\"blog/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?blog=$matches[1]&page=$matches[2]\";s:21:\"blog/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"blog/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"blog/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"blog/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"blog/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"blog/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:54:\"blog/category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?blog_category=$matches[1]&feed=$matches[2]\";s:49:\"blog/category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?blog_category=$matches[1]&feed=$matches[2]\";s:30:\"blog/category/([^/]+)/embed/?$\";s:46:\"index.php?blog_category=$matches[1]&embed=true\";s:42:\"blog/category/([^/]+)/page/?([0-9]{1,})/?$\";s:53:\"index.php?blog_category=$matches[1]&paged=$matches[2]\";s:24:\"blog/category/([^/]+)/?$\";s:35:\"index.php?blog_category=$matches[1]\";s:36:\"services/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"services/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"services/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"services/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"services/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"services/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"services/([^/]+)/embed/?$\";s:41:\"index.php?services=$matches[1]&embed=true\";s:29:\"services/([^/]+)/trackback/?$\";s:35:\"index.php?services=$matches[1]&tb=1\";s:49:\"services/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?services=$matches[1]&feed=$matches[2]\";s:44:\"services/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?services=$matches[1]&feed=$matches[2]\";s:37:\"services/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?services=$matches[1]&paged=$matches[2]\";s:44:\"services/([^/]+)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?services=$matches[1]&cpage=$matches[2]\";s:33:\"services/([^/]+)(?:/([0-9]+))?/?$\";s:47:\"index.php?services=$matches[1]&page=$matches[2]\";s:25:\"services/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"services/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"services/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"services/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"services/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"services/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:13:\"favicon\\.ico$\";s:19:\"index.php?favicon=1\";s:12:\"sitemap\\.xml\";s:23:\"index.php?sitemap=index\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=7&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','on'),
(31,'hack_file','0','on'),
(32,'blog_charset','UTF-8','on'),
(33,'moderation_keys','','off'),
(34,'active_plugins','a:6:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:29:\"bamboo-tools/bamboo-tools.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:22:\"cyr2lat/cyr-to-lat.php\";i:4;s:53:\"simple-custom-post-order/simple-custom-post-order.php\";i:5;s:33:\"wps-hide-login/wps-hide-login.php\";}','on'),
(35,'category_base','','on'),
(36,'ping_sites','https://rpc.pingomatic.com/','on'),
(37,'comment_max_links','2','on'),
(38,'gmt_offset','2','on'),
(39,'default_email_category','1','on'),
(40,'recently_edited','','off'),
(41,'template','bamboo','on'),
(42,'stylesheet','bamboo','on'),
(43,'comment_registration','0','on'),
(44,'html_type','text/html','on'),
(45,'use_trackback','0','on'),
(46,'default_role','subscriber','on'),
(47,'db_version','60717','on'),
(48,'uploads_use_yearmonth_folders','1','on'),
(49,'upload_path','','on'),
(50,'blog_public','0','on'),
(51,'default_link_category','2','on'),
(52,'show_on_front','page','on'),
(53,'tag_base','','on'),
(54,'show_avatars','1','on'),
(55,'avatar_rating','G','on'),
(56,'upload_url_path','','on'),
(57,'thumbnail_size_w','150','on'),
(58,'thumbnail_size_h','150','on'),
(59,'thumbnail_crop','1','on'),
(60,'medium_size_w','300','on'),
(61,'medium_size_h','300','on'),
(62,'avatar_default','mystery','on'),
(63,'large_size_w','1024','on'),
(64,'large_size_h','1024','on'),
(65,'image_default_link_type','none','on'),
(66,'image_default_size','','on'),
(67,'image_default_align','','on'),
(68,'close_comments_for_old_posts','0','on'),
(69,'close_comments_days_old','14','on'),
(70,'thread_comments','1','on'),
(71,'thread_comments_depth','5','on'),
(72,'page_comments','0','on'),
(73,'comments_per_page','50','on'),
(74,'default_comments_page','newest','on'),
(75,'comment_order','asc','on'),
(76,'sticky_posts','a:0:{}','on'),
(77,'widget_categories','a:0:{}','on'),
(78,'widget_text','a:0:{}','on'),
(79,'widget_rss','a:0:{}','on'),
(80,'uninstall_plugins','a:1:{s:53:\"simple-custom-post-order/simple-custom-post-order.php\";s:18:\"scporder_uninstall\";}','off'),
(81,'timezone_string','','on'),
(82,'page_for_posts','13','on'),
(83,'page_on_front','7','on'),
(84,'default_post_format','0','on'),
(85,'link_manager_enabled','0','on'),
(86,'finished_splitting_shared_terms','1','on'),
(87,'site_icon','133','on'),
(88,'medium_large_size_w','768','on'),
(89,'medium_large_size_h','0','on'),
(90,'wp_page_for_privacy_policy','3','on'),
(91,'show_comments_cookies_opt_in','1','on'),
(92,'admin_email_lifespan','1789233330','on'),
(93,'disallowed_keys','','off'),
(94,'comment_previously_approved','1','on'),
(95,'auto_plugin_theme_update_emails','a:0:{}','off'),
(96,'auto_update_core_dev','enabled','on'),
(97,'auto_update_core_minor','enabled','on'),
(98,'auto_update_core_major','enabled','on'),
(99,'wp_force_deactivated_plugins','a:0:{}','on'),
(100,'wp_attachment_pages_enabled','0','on'),
(101,'wp_notes_notify','1','on'),
(102,'initial_db_version','60717','on'),
(103,'bb_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','on'),
(104,'fresh_site','0','off'),
(105,'user_count','1','off'),
(106,'widget_block','a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}','auto'),
(107,'sidebars_widgets','a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:13:\"array_version\";i:3;}','auto'),
(108,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(109,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(110,'widget_archives','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(111,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(112,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(113,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(114,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(115,'widget_meta','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(116,'widget_search','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(117,'widget_recent-posts','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(118,'widget_recent-comments','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(119,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(120,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(121,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','auto'),
(125,'theme_mods_twentytwentyfive','a:1:{s:18:\"custom_css_post_id\";i:-1;}','auto'),
(128,'recovery_keys','a:0:{}','off'),
(129,'_transient_wp_core_block_css_files','a:2:{s:7:\"version\";s:5:\"6.9.4\";s:5:\"files\";a:584:{i:0;s:31:\"accordion-heading/style-rtl.css\";i:1;s:35:\"accordion-heading/style-rtl.min.css\";i:2;s:27:\"accordion-heading/style.css\";i:3;s:31:\"accordion-heading/style.min.css\";i:4;s:28:\"accordion-item/style-rtl.css\";i:5;s:32:\"accordion-item/style-rtl.min.css\";i:6;s:24:\"accordion-item/style.css\";i:7;s:28:\"accordion-item/style.min.css\";i:8;s:29:\"accordion-panel/style-rtl.css\";i:9;s:33:\"accordion-panel/style-rtl.min.css\";i:10;s:25:\"accordion-panel/style.css\";i:11;s:29:\"accordion-panel/style.min.css\";i:12;s:23:\"accordion/style-rtl.css\";i:13;s:27:\"accordion/style-rtl.min.css\";i:14;s:19:\"accordion/style.css\";i:15;s:23:\"accordion/style.min.css\";i:16;s:23:\"archives/editor-rtl.css\";i:17;s:27:\"archives/editor-rtl.min.css\";i:18;s:19:\"archives/editor.css\";i:19;s:23:\"archives/editor.min.css\";i:20;s:22:\"archives/style-rtl.css\";i:21;s:26:\"archives/style-rtl.min.css\";i:22;s:18:\"archives/style.css\";i:23;s:22:\"archives/style.min.css\";i:24;s:20:\"audio/editor-rtl.css\";i:25;s:24:\"audio/editor-rtl.min.css\";i:26;s:16:\"audio/editor.css\";i:27;s:20:\"audio/editor.min.css\";i:28;s:19:\"audio/style-rtl.css\";i:29;s:23:\"audio/style-rtl.min.css\";i:30;s:15:\"audio/style.css\";i:31;s:19:\"audio/style.min.css\";i:32;s:19:\"audio/theme-rtl.css\";i:33;s:23:\"audio/theme-rtl.min.css\";i:34;s:15:\"audio/theme.css\";i:35;s:19:\"audio/theme.min.css\";i:36;s:21:\"avatar/editor-rtl.css\";i:37;s:25:\"avatar/editor-rtl.min.css\";i:38;s:17:\"avatar/editor.css\";i:39;s:21:\"avatar/editor.min.css\";i:40;s:20:\"avatar/style-rtl.css\";i:41;s:24:\"avatar/style-rtl.min.css\";i:42;s:16:\"avatar/style.css\";i:43;s:20:\"avatar/style.min.css\";i:44;s:21:\"button/editor-rtl.css\";i:45;s:25:\"button/editor-rtl.min.css\";i:46;s:17:\"button/editor.css\";i:47;s:21:\"button/editor.min.css\";i:48;s:20:\"button/style-rtl.css\";i:49;s:24:\"button/style-rtl.min.css\";i:50;s:16:\"button/style.css\";i:51;s:20:\"button/style.min.css\";i:52;s:22:\"buttons/editor-rtl.css\";i:53;s:26:\"buttons/editor-rtl.min.css\";i:54;s:18:\"buttons/editor.css\";i:55;s:22:\"buttons/editor.min.css\";i:56;s:21:\"buttons/style-rtl.css\";i:57;s:25:\"buttons/style-rtl.min.css\";i:58;s:17:\"buttons/style.css\";i:59;s:21:\"buttons/style.min.css\";i:60;s:22:\"calendar/style-rtl.css\";i:61;s:26:\"calendar/style-rtl.min.css\";i:62;s:18:\"calendar/style.css\";i:63;s:22:\"calendar/style.min.css\";i:64;s:25:\"categories/editor-rtl.css\";i:65;s:29:\"categories/editor-rtl.min.css\";i:66;s:21:\"categories/editor.css\";i:67;s:25:\"categories/editor.min.css\";i:68;s:24:\"categories/style-rtl.css\";i:69;s:28:\"categories/style-rtl.min.css\";i:70;s:20:\"categories/style.css\";i:71;s:24:\"categories/style.min.css\";i:72;s:19:\"code/editor-rtl.css\";i:73;s:23:\"code/editor-rtl.min.css\";i:74;s:15:\"code/editor.css\";i:75;s:19:\"code/editor.min.css\";i:76;s:18:\"code/style-rtl.css\";i:77;s:22:\"code/style-rtl.min.css\";i:78;s:14:\"code/style.css\";i:79;s:18:\"code/style.min.css\";i:80;s:18:\"code/theme-rtl.css\";i:81;s:22:\"code/theme-rtl.min.css\";i:82;s:14:\"code/theme.css\";i:83;s:18:\"code/theme.min.css\";i:84;s:22:\"columns/editor-rtl.css\";i:85;s:26:\"columns/editor-rtl.min.css\";i:86;s:18:\"columns/editor.css\";i:87;s:22:\"columns/editor.min.css\";i:88;s:21:\"columns/style-rtl.css\";i:89;s:25:\"columns/style-rtl.min.css\";i:90;s:17:\"columns/style.css\";i:91;s:21:\"columns/style.min.css\";i:92;s:33:\"comment-author-name/style-rtl.css\";i:93;s:37:\"comment-author-name/style-rtl.min.css\";i:94;s:29:\"comment-author-name/style.css\";i:95;s:33:\"comment-author-name/style.min.css\";i:96;s:29:\"comment-content/style-rtl.css\";i:97;s:33:\"comment-content/style-rtl.min.css\";i:98;s:25:\"comment-content/style.css\";i:99;s:29:\"comment-content/style.min.css\";i:100;s:26:\"comment-date/style-rtl.css\";i:101;s:30:\"comment-date/style-rtl.min.css\";i:102;s:22:\"comment-date/style.css\";i:103;s:26:\"comment-date/style.min.css\";i:104;s:31:\"comment-edit-link/style-rtl.css\";i:105;s:35:\"comment-edit-link/style-rtl.min.css\";i:106;s:27:\"comment-edit-link/style.css\";i:107;s:31:\"comment-edit-link/style.min.css\";i:108;s:32:\"comment-reply-link/style-rtl.css\";i:109;s:36:\"comment-reply-link/style-rtl.min.css\";i:110;s:28:\"comment-reply-link/style.css\";i:111;s:32:\"comment-reply-link/style.min.css\";i:112;s:30:\"comment-template/style-rtl.css\";i:113;s:34:\"comment-template/style-rtl.min.css\";i:114;s:26:\"comment-template/style.css\";i:115;s:30:\"comment-template/style.min.css\";i:116;s:42:\"comments-pagination-numbers/editor-rtl.css\";i:117;s:46:\"comments-pagination-numbers/editor-rtl.min.css\";i:118;s:38:\"comments-pagination-numbers/editor.css\";i:119;s:42:\"comments-pagination-numbers/editor.min.css\";i:120;s:34:\"comments-pagination/editor-rtl.css\";i:121;s:38:\"comments-pagination/editor-rtl.min.css\";i:122;s:30:\"comments-pagination/editor.css\";i:123;s:34:\"comments-pagination/editor.min.css\";i:124;s:33:\"comments-pagination/style-rtl.css\";i:125;s:37:\"comments-pagination/style-rtl.min.css\";i:126;s:29:\"comments-pagination/style.css\";i:127;s:33:\"comments-pagination/style.min.css\";i:128;s:29:\"comments-title/editor-rtl.css\";i:129;s:33:\"comments-title/editor-rtl.min.css\";i:130;s:25:\"comments-title/editor.css\";i:131;s:29:\"comments-title/editor.min.css\";i:132;s:23:\"comments/editor-rtl.css\";i:133;s:27:\"comments/editor-rtl.min.css\";i:134;s:19:\"comments/editor.css\";i:135;s:23:\"comments/editor.min.css\";i:136;s:22:\"comments/style-rtl.css\";i:137;s:26:\"comments/style-rtl.min.css\";i:138;s:18:\"comments/style.css\";i:139;s:22:\"comments/style.min.css\";i:140;s:20:\"cover/editor-rtl.css\";i:141;s:24:\"cover/editor-rtl.min.css\";i:142;s:16:\"cover/editor.css\";i:143;s:20:\"cover/editor.min.css\";i:144;s:19:\"cover/style-rtl.css\";i:145;s:23:\"cover/style-rtl.min.css\";i:146;s:15:\"cover/style.css\";i:147;s:19:\"cover/style.min.css\";i:148;s:22:\"details/editor-rtl.css\";i:149;s:26:\"details/editor-rtl.min.css\";i:150;s:18:\"details/editor.css\";i:151;s:22:\"details/editor.min.css\";i:152;s:21:\"details/style-rtl.css\";i:153;s:25:\"details/style-rtl.min.css\";i:154;s:17:\"details/style.css\";i:155;s:21:\"details/style.min.css\";i:156;s:20:\"embed/editor-rtl.css\";i:157;s:24:\"embed/editor-rtl.min.css\";i:158;s:16:\"embed/editor.css\";i:159;s:20:\"embed/editor.min.css\";i:160;s:19:\"embed/style-rtl.css\";i:161;s:23:\"embed/style-rtl.min.css\";i:162;s:15:\"embed/style.css\";i:163;s:19:\"embed/style.min.css\";i:164;s:19:\"embed/theme-rtl.css\";i:165;s:23:\"embed/theme-rtl.min.css\";i:166;s:15:\"embed/theme.css\";i:167;s:19:\"embed/theme.min.css\";i:168;s:19:\"file/editor-rtl.css\";i:169;s:23:\"file/editor-rtl.min.css\";i:170;s:15:\"file/editor.css\";i:171;s:19:\"file/editor.min.css\";i:172;s:18:\"file/style-rtl.css\";i:173;s:22:\"file/style-rtl.min.css\";i:174;s:14:\"file/style.css\";i:175;s:18:\"file/style.min.css\";i:176;s:23:\"footnotes/style-rtl.css\";i:177;s:27:\"footnotes/style-rtl.min.css\";i:178;s:19:\"footnotes/style.css\";i:179;s:23:\"footnotes/style.min.css\";i:180;s:23:\"freeform/editor-rtl.css\";i:181;s:27:\"freeform/editor-rtl.min.css\";i:182;s:19:\"freeform/editor.css\";i:183;s:23:\"freeform/editor.min.css\";i:184;s:22:\"gallery/editor-rtl.css\";i:185;s:26:\"gallery/editor-rtl.min.css\";i:186;s:18:\"gallery/editor.css\";i:187;s:22:\"gallery/editor.min.css\";i:188;s:21:\"gallery/style-rtl.css\";i:189;s:25:\"gallery/style-rtl.min.css\";i:190;s:17:\"gallery/style.css\";i:191;s:21:\"gallery/style.min.css\";i:192;s:21:\"gallery/theme-rtl.css\";i:193;s:25:\"gallery/theme-rtl.min.css\";i:194;s:17:\"gallery/theme.css\";i:195;s:21:\"gallery/theme.min.css\";i:196;s:20:\"group/editor-rtl.css\";i:197;s:24:\"group/editor-rtl.min.css\";i:198;s:16:\"group/editor.css\";i:199;s:20:\"group/editor.min.css\";i:200;s:19:\"group/style-rtl.css\";i:201;s:23:\"group/style-rtl.min.css\";i:202;s:15:\"group/style.css\";i:203;s:19:\"group/style.min.css\";i:204;s:19:\"group/theme-rtl.css\";i:205;s:23:\"group/theme-rtl.min.css\";i:206;s:15:\"group/theme.css\";i:207;s:19:\"group/theme.min.css\";i:208;s:21:\"heading/style-rtl.css\";i:209;s:25:\"heading/style-rtl.min.css\";i:210;s:17:\"heading/style.css\";i:211;s:21:\"heading/style.min.css\";i:212;s:19:\"html/editor-rtl.css\";i:213;s:23:\"html/editor-rtl.min.css\";i:214;s:15:\"html/editor.css\";i:215;s:19:\"html/editor.min.css\";i:216;s:20:\"image/editor-rtl.css\";i:217;s:24:\"image/editor-rtl.min.css\";i:218;s:16:\"image/editor.css\";i:219;s:20:\"image/editor.min.css\";i:220;s:19:\"image/style-rtl.css\";i:221;s:23:\"image/style-rtl.min.css\";i:222;s:15:\"image/style.css\";i:223;s:19:\"image/style.min.css\";i:224;s:19:\"image/theme-rtl.css\";i:225;s:23:\"image/theme-rtl.min.css\";i:226;s:15:\"image/theme.css\";i:227;s:19:\"image/theme.min.css\";i:228;s:29:\"latest-comments/style-rtl.css\";i:229;s:33:\"latest-comments/style-rtl.min.css\";i:230;s:25:\"latest-comments/style.css\";i:231;s:29:\"latest-comments/style.min.css\";i:232;s:27:\"latest-posts/editor-rtl.css\";i:233;s:31:\"latest-posts/editor-rtl.min.css\";i:234;s:23:\"latest-posts/editor.css\";i:235;s:27:\"latest-posts/editor.min.css\";i:236;s:26:\"latest-posts/style-rtl.css\";i:237;s:30:\"latest-posts/style-rtl.min.css\";i:238;s:22:\"latest-posts/style.css\";i:239;s:26:\"latest-posts/style.min.css\";i:240;s:18:\"list/style-rtl.css\";i:241;s:22:\"list/style-rtl.min.css\";i:242;s:14:\"list/style.css\";i:243;s:18:\"list/style.min.css\";i:244;s:22:\"loginout/style-rtl.css\";i:245;s:26:\"loginout/style-rtl.min.css\";i:246;s:18:\"loginout/style.css\";i:247;s:22:\"loginout/style.min.css\";i:248;s:19:\"math/editor-rtl.css\";i:249;s:23:\"math/editor-rtl.min.css\";i:250;s:15:\"math/editor.css\";i:251;s:19:\"math/editor.min.css\";i:252;s:18:\"math/style-rtl.css\";i:253;s:22:\"math/style-rtl.min.css\";i:254;s:14:\"math/style.css\";i:255;s:18:\"math/style.min.css\";i:256;s:25:\"media-text/editor-rtl.css\";i:257;s:29:\"media-text/editor-rtl.min.css\";i:258;s:21:\"media-text/editor.css\";i:259;s:25:\"media-text/editor.min.css\";i:260;s:24:\"media-text/style-rtl.css\";i:261;s:28:\"media-text/style-rtl.min.css\";i:262;s:20:\"media-text/style.css\";i:263;s:24:\"media-text/style.min.css\";i:264;s:19:\"more/editor-rtl.css\";i:265;s:23:\"more/editor-rtl.min.css\";i:266;s:15:\"more/editor.css\";i:267;s:19:\"more/editor.min.css\";i:268;s:30:\"navigation-link/editor-rtl.css\";i:269;s:34:\"navigation-link/editor-rtl.min.css\";i:270;s:26:\"navigation-link/editor.css\";i:271;s:30:\"navigation-link/editor.min.css\";i:272;s:29:\"navigation-link/style-rtl.css\";i:273;s:33:\"navigation-link/style-rtl.min.css\";i:274;s:25:\"navigation-link/style.css\";i:275;s:29:\"navigation-link/style.min.css\";i:276;s:33:\"navigation-submenu/editor-rtl.css\";i:277;s:37:\"navigation-submenu/editor-rtl.min.css\";i:278;s:29:\"navigation-submenu/editor.css\";i:279;s:33:\"navigation-submenu/editor.min.css\";i:280;s:25:\"navigation/editor-rtl.css\";i:281;s:29:\"navigation/editor-rtl.min.css\";i:282;s:21:\"navigation/editor.css\";i:283;s:25:\"navigation/editor.min.css\";i:284;s:24:\"navigation/style-rtl.css\";i:285;s:28:\"navigation/style-rtl.min.css\";i:286;s:20:\"navigation/style.css\";i:287;s:24:\"navigation/style.min.css\";i:288;s:23:\"nextpage/editor-rtl.css\";i:289;s:27:\"nextpage/editor-rtl.min.css\";i:290;s:19:\"nextpage/editor.css\";i:291;s:23:\"nextpage/editor.min.css\";i:292;s:24:\"page-list/editor-rtl.css\";i:293;s:28:\"page-list/editor-rtl.min.css\";i:294;s:20:\"page-list/editor.css\";i:295;s:24:\"page-list/editor.min.css\";i:296;s:23:\"page-list/style-rtl.css\";i:297;s:27:\"page-list/style-rtl.min.css\";i:298;s:19:\"page-list/style.css\";i:299;s:23:\"page-list/style.min.css\";i:300;s:24:\"paragraph/editor-rtl.css\";i:301;s:28:\"paragraph/editor-rtl.min.css\";i:302;s:20:\"paragraph/editor.css\";i:303;s:24:\"paragraph/editor.min.css\";i:304;s:23:\"paragraph/style-rtl.css\";i:305;s:27:\"paragraph/style-rtl.min.css\";i:306;s:19:\"paragraph/style.css\";i:307;s:23:\"paragraph/style.min.css\";i:308;s:35:\"post-author-biography/style-rtl.css\";i:309;s:39:\"post-author-biography/style-rtl.min.css\";i:310;s:31:\"post-author-biography/style.css\";i:311;s:35:\"post-author-biography/style.min.css\";i:312;s:30:\"post-author-name/style-rtl.css\";i:313;s:34:\"post-author-name/style-rtl.min.css\";i:314;s:26:\"post-author-name/style.css\";i:315;s:30:\"post-author-name/style.min.css\";i:316;s:25:\"post-author/style-rtl.css\";i:317;s:29:\"post-author/style-rtl.min.css\";i:318;s:21:\"post-author/style.css\";i:319;s:25:\"post-author/style.min.css\";i:320;s:33:\"post-comments-count/style-rtl.css\";i:321;s:37:\"post-comments-count/style-rtl.min.css\";i:322;s:29:\"post-comments-count/style.css\";i:323;s:33:\"post-comments-count/style.min.css\";i:324;s:33:\"post-comments-form/editor-rtl.css\";i:325;s:37:\"post-comments-form/editor-rtl.min.css\";i:326;s:29:\"post-comments-form/editor.css\";i:327;s:33:\"post-comments-form/editor.min.css\";i:328;s:32:\"post-comments-form/style-rtl.css\";i:329;s:36:\"post-comments-form/style-rtl.min.css\";i:330;s:28:\"post-comments-form/style.css\";i:331;s:32:\"post-comments-form/style.min.css\";i:332;s:32:\"post-comments-link/style-rtl.css\";i:333;s:36:\"post-comments-link/style-rtl.min.css\";i:334;s:28:\"post-comments-link/style.css\";i:335;s:32:\"post-comments-link/style.min.css\";i:336;s:26:\"post-content/style-rtl.css\";i:337;s:30:\"post-content/style-rtl.min.css\";i:338;s:22:\"post-content/style.css\";i:339;s:26:\"post-content/style.min.css\";i:340;s:23:\"post-date/style-rtl.css\";i:341;s:27:\"post-date/style-rtl.min.css\";i:342;s:19:\"post-date/style.css\";i:343;s:23:\"post-date/style.min.css\";i:344;s:27:\"post-excerpt/editor-rtl.css\";i:345;s:31:\"post-excerpt/editor-rtl.min.css\";i:346;s:23:\"post-excerpt/editor.css\";i:347;s:27:\"post-excerpt/editor.min.css\";i:348;s:26:\"post-excerpt/style-rtl.css\";i:349;s:30:\"post-excerpt/style-rtl.min.css\";i:350;s:22:\"post-excerpt/style.css\";i:351;s:26:\"post-excerpt/style.min.css\";i:352;s:34:\"post-featured-image/editor-rtl.css\";i:353;s:38:\"post-featured-image/editor-rtl.min.css\";i:354;s:30:\"post-featured-image/editor.css\";i:355;s:34:\"post-featured-image/editor.min.css\";i:356;s:33:\"post-featured-image/style-rtl.css\";i:357;s:37:\"post-featured-image/style-rtl.min.css\";i:358;s:29:\"post-featured-image/style.css\";i:359;s:33:\"post-featured-image/style.min.css\";i:360;s:34:\"post-navigation-link/style-rtl.css\";i:361;s:38:\"post-navigation-link/style-rtl.min.css\";i:362;s:30:\"post-navigation-link/style.css\";i:363;s:34:\"post-navigation-link/style.min.css\";i:364;s:27:\"post-template/style-rtl.css\";i:365;s:31:\"post-template/style-rtl.min.css\";i:366;s:23:\"post-template/style.css\";i:367;s:27:\"post-template/style.min.css\";i:368;s:24:\"post-terms/style-rtl.css\";i:369;s:28:\"post-terms/style-rtl.min.css\";i:370;s:20:\"post-terms/style.css\";i:371;s:24:\"post-terms/style.min.css\";i:372;s:31:\"post-time-to-read/style-rtl.css\";i:373;s:35:\"post-time-to-read/style-rtl.min.css\";i:374;s:27:\"post-time-to-read/style.css\";i:375;s:31:\"post-time-to-read/style.min.css\";i:376;s:24:\"post-title/style-rtl.css\";i:377;s:28:\"post-title/style-rtl.min.css\";i:378;s:20:\"post-title/style.css\";i:379;s:24:\"post-title/style.min.css\";i:380;s:26:\"preformatted/style-rtl.css\";i:381;s:30:\"preformatted/style-rtl.min.css\";i:382;s:22:\"preformatted/style.css\";i:383;s:26:\"preformatted/style.min.css\";i:384;s:24:\"pullquote/editor-rtl.css\";i:385;s:28:\"pullquote/editor-rtl.min.css\";i:386;s:20:\"pullquote/editor.css\";i:387;s:24:\"pullquote/editor.min.css\";i:388;s:23:\"pullquote/style-rtl.css\";i:389;s:27:\"pullquote/style-rtl.min.css\";i:390;s:19:\"pullquote/style.css\";i:391;s:23:\"pullquote/style.min.css\";i:392;s:23:\"pullquote/theme-rtl.css\";i:393;s:27:\"pullquote/theme-rtl.min.css\";i:394;s:19:\"pullquote/theme.css\";i:395;s:23:\"pullquote/theme.min.css\";i:396;s:39:\"query-pagination-numbers/editor-rtl.css\";i:397;s:43:\"query-pagination-numbers/editor-rtl.min.css\";i:398;s:35:\"query-pagination-numbers/editor.css\";i:399;s:39:\"query-pagination-numbers/editor.min.css\";i:400;s:31:\"query-pagination/editor-rtl.css\";i:401;s:35:\"query-pagination/editor-rtl.min.css\";i:402;s:27:\"query-pagination/editor.css\";i:403;s:31:\"query-pagination/editor.min.css\";i:404;s:30:\"query-pagination/style-rtl.css\";i:405;s:34:\"query-pagination/style-rtl.min.css\";i:406;s:26:\"query-pagination/style.css\";i:407;s:30:\"query-pagination/style.min.css\";i:408;s:25:\"query-title/style-rtl.css\";i:409;s:29:\"query-title/style-rtl.min.css\";i:410;s:21:\"query-title/style.css\";i:411;s:25:\"query-title/style.min.css\";i:412;s:25:\"query-total/style-rtl.css\";i:413;s:29:\"query-total/style-rtl.min.css\";i:414;s:21:\"query-total/style.css\";i:415;s:25:\"query-total/style.min.css\";i:416;s:20:\"query/editor-rtl.css\";i:417;s:24:\"query/editor-rtl.min.css\";i:418;s:16:\"query/editor.css\";i:419;s:20:\"query/editor.min.css\";i:420;s:19:\"quote/style-rtl.css\";i:421;s:23:\"quote/style-rtl.min.css\";i:422;s:15:\"quote/style.css\";i:423;s:19:\"quote/style.min.css\";i:424;s:19:\"quote/theme-rtl.css\";i:425;s:23:\"quote/theme-rtl.min.css\";i:426;s:15:\"quote/theme.css\";i:427;s:19:\"quote/theme.min.css\";i:428;s:23:\"read-more/style-rtl.css\";i:429;s:27:\"read-more/style-rtl.min.css\";i:430;s:19:\"read-more/style.css\";i:431;s:23:\"read-more/style.min.css\";i:432;s:18:\"rss/editor-rtl.css\";i:433;s:22:\"rss/editor-rtl.min.css\";i:434;s:14:\"rss/editor.css\";i:435;s:18:\"rss/editor.min.css\";i:436;s:17:\"rss/style-rtl.css\";i:437;s:21:\"rss/style-rtl.min.css\";i:438;s:13:\"rss/style.css\";i:439;s:17:\"rss/style.min.css\";i:440;s:21:\"search/editor-rtl.css\";i:441;s:25:\"search/editor-rtl.min.css\";i:442;s:17:\"search/editor.css\";i:443;s:21:\"search/editor.min.css\";i:444;s:20:\"search/style-rtl.css\";i:445;s:24:\"search/style-rtl.min.css\";i:446;s:16:\"search/style.css\";i:447;s:20:\"search/style.min.css\";i:448;s:20:\"search/theme-rtl.css\";i:449;s:24:\"search/theme-rtl.min.css\";i:450;s:16:\"search/theme.css\";i:451;s:20:\"search/theme.min.css\";i:452;s:24:\"separator/editor-rtl.css\";i:453;s:28:\"separator/editor-rtl.min.css\";i:454;s:20:\"separator/editor.css\";i:455;s:24:\"separator/editor.min.css\";i:456;s:23:\"separator/style-rtl.css\";i:457;s:27:\"separator/style-rtl.min.css\";i:458;s:19:\"separator/style.css\";i:459;s:23:\"separator/style.min.css\";i:460;s:23:\"separator/theme-rtl.css\";i:461;s:27:\"separator/theme-rtl.min.css\";i:462;s:19:\"separator/theme.css\";i:463;s:23:\"separator/theme.min.css\";i:464;s:24:\"shortcode/editor-rtl.css\";i:465;s:28:\"shortcode/editor-rtl.min.css\";i:466;s:20:\"shortcode/editor.css\";i:467;s:24:\"shortcode/editor.min.css\";i:468;s:24:\"site-logo/editor-rtl.css\";i:469;s:28:\"site-logo/editor-rtl.min.css\";i:470;s:20:\"site-logo/editor.css\";i:471;s:24:\"site-logo/editor.min.css\";i:472;s:23:\"site-logo/style-rtl.css\";i:473;s:27:\"site-logo/style-rtl.min.css\";i:474;s:19:\"site-logo/style.css\";i:475;s:23:\"site-logo/style.min.css\";i:476;s:27:\"site-tagline/editor-rtl.css\";i:477;s:31:\"site-tagline/editor-rtl.min.css\";i:478;s:23:\"site-tagline/editor.css\";i:479;s:27:\"site-tagline/editor.min.css\";i:480;s:26:\"site-tagline/style-rtl.css\";i:481;s:30:\"site-tagline/style-rtl.min.css\";i:482;s:22:\"site-tagline/style.css\";i:483;s:26:\"site-tagline/style.min.css\";i:484;s:25:\"site-title/editor-rtl.css\";i:485;s:29:\"site-title/editor-rtl.min.css\";i:486;s:21:\"site-title/editor.css\";i:487;s:25:\"site-title/editor.min.css\";i:488;s:24:\"site-title/style-rtl.css\";i:489;s:28:\"site-title/style-rtl.min.css\";i:490;s:20:\"site-title/style.css\";i:491;s:24:\"site-title/style.min.css\";i:492;s:26:\"social-link/editor-rtl.css\";i:493;s:30:\"social-link/editor-rtl.min.css\";i:494;s:22:\"social-link/editor.css\";i:495;s:26:\"social-link/editor.min.css\";i:496;s:27:\"social-links/editor-rtl.css\";i:497;s:31:\"social-links/editor-rtl.min.css\";i:498;s:23:\"social-links/editor.css\";i:499;s:27:\"social-links/editor.min.css\";i:500;s:26:\"social-links/style-rtl.css\";i:501;s:30:\"social-links/style-rtl.min.css\";i:502;s:22:\"social-links/style.css\";i:503;s:26:\"social-links/style.min.css\";i:504;s:21:\"spacer/editor-rtl.css\";i:505;s:25:\"spacer/editor-rtl.min.css\";i:506;s:17:\"spacer/editor.css\";i:507;s:21:\"spacer/editor.min.css\";i:508;s:20:\"spacer/style-rtl.css\";i:509;s:24:\"spacer/style-rtl.min.css\";i:510;s:16:\"spacer/style.css\";i:511;s:20:\"spacer/style.min.css\";i:512;s:20:\"table/editor-rtl.css\";i:513;s:24:\"table/editor-rtl.min.css\";i:514;s:16:\"table/editor.css\";i:515;s:20:\"table/editor.min.css\";i:516;s:19:\"table/style-rtl.css\";i:517;s:23:\"table/style-rtl.min.css\";i:518;s:15:\"table/style.css\";i:519;s:19:\"table/style.min.css\";i:520;s:19:\"table/theme-rtl.css\";i:521;s:23:\"table/theme-rtl.min.css\";i:522;s:15:\"table/theme.css\";i:523;s:19:\"table/theme.min.css\";i:524;s:24:\"tag-cloud/editor-rtl.css\";i:525;s:28:\"tag-cloud/editor-rtl.min.css\";i:526;s:20:\"tag-cloud/editor.css\";i:527;s:24:\"tag-cloud/editor.min.css\";i:528;s:23:\"tag-cloud/style-rtl.css\";i:529;s:27:\"tag-cloud/style-rtl.min.css\";i:530;s:19:\"tag-cloud/style.css\";i:531;s:23:\"tag-cloud/style.min.css\";i:532;s:28:\"template-part/editor-rtl.css\";i:533;s:32:\"template-part/editor-rtl.min.css\";i:534;s:24:\"template-part/editor.css\";i:535;s:28:\"template-part/editor.min.css\";i:536;s:27:\"template-part/theme-rtl.css\";i:537;s:31:\"template-part/theme-rtl.min.css\";i:538;s:23:\"template-part/theme.css\";i:539;s:27:\"template-part/theme.min.css\";i:540;s:24:\"term-count/style-rtl.css\";i:541;s:28:\"term-count/style-rtl.min.css\";i:542;s:20:\"term-count/style.css\";i:543;s:24:\"term-count/style.min.css\";i:544;s:30:\"term-description/style-rtl.css\";i:545;s:34:\"term-description/style-rtl.min.css\";i:546;s:26:\"term-description/style.css\";i:547;s:30:\"term-description/style.min.css\";i:548;s:23:\"term-name/style-rtl.css\";i:549;s:27:\"term-name/style-rtl.min.css\";i:550;s:19:\"term-name/style.css\";i:551;s:23:\"term-name/style.min.css\";i:552;s:28:\"term-template/editor-rtl.css\";i:553;s:32:\"term-template/editor-rtl.min.css\";i:554;s:24:\"term-template/editor.css\";i:555;s:28:\"term-template/editor.min.css\";i:556;s:27:\"term-template/style-rtl.css\";i:557;s:31:\"term-template/style-rtl.min.css\";i:558;s:23:\"term-template/style.css\";i:559;s:27:\"term-template/style.min.css\";i:560;s:27:\"text-columns/editor-rtl.css\";i:561;s:31:\"text-columns/editor-rtl.min.css\";i:562;s:23:\"text-columns/editor.css\";i:563;s:27:\"text-columns/editor.min.css\";i:564;s:26:\"text-columns/style-rtl.css\";i:565;s:30:\"text-columns/style-rtl.min.css\";i:566;s:22:\"text-columns/style.css\";i:567;s:26:\"text-columns/style.min.css\";i:568;s:19:\"verse/style-rtl.css\";i:569;s:23:\"verse/style-rtl.min.css\";i:570;s:15:\"verse/style.css\";i:571;s:19:\"verse/style.min.css\";i:572;s:20:\"video/editor-rtl.css\";i:573;s:24:\"video/editor-rtl.min.css\";i:574;s:16:\"video/editor.css\";i:575;s:20:\"video/editor.min.css\";i:576;s:19:\"video/style-rtl.css\";i:577;s:23:\"video/style-rtl.min.css\";i:578;s:15:\"video/style.css\";i:579;s:19:\"video/style.min.css\";i:580;s:19:\"video/theme-rtl.css\";i:581;s:23:\"video/theme-rtl.min.css\";i:582;s:15:\"video/theme.css\";i:583;s:19:\"video/theme.min.css\";}}','on'),
(132,'theme_mods_bamboo','a:3:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:11:\"header_menu\";i:2;s:11:\"footer_menu\";i:3;}s:11:\"custom_logo\";i:138;}','auto'),
(138,'finished_updating_comment_type','1','auto'),
(142,'can_compress_scripts','1','on'),
(150,'wp_calendar_block_has_published_posts','','auto'),
(157,'WPLANG','uk','auto'),
(158,'new_admin_email','romecom2210@gmail.com','auto'),
(194,'_site_transient_wp_plugin_dependencies_plugin_data','a:0:{}','off'),
(195,'recently_activated','a:0:{}','off'),
(196,'acf_first_activated_version','6.7.1','on'),
(197,'acf_site_health','{\"version\":\"6.7.1\",\"plugin_type\":\"PRO\",\"update_source\":\"ACF Direct\",\"activated\":true,\"activated_url\":\"http:\\/\\/imp.loc\",\"license_type\":\"Developer\",\"license_status\":\"active\",\"subscription_expires\":\"\",\"wp_version\":\"6.9.4\",\"mysql_version\":\"11.8.5-MariaDB-log\",\"is_multisite\":false,\"active_theme\":{\"name\":\"Bamboo\",\"version\":\"3.0\",\"theme_uri\":\"http:\\/\\/bambukstudio.com\",\"stylesheet\":false},\"active_plugins\":{\"advanced-custom-fields-pro\\/acf.php\":{\"name\":\"Advanced Custom Fields PRO\",\"version\":\"6.7.1\",\"plugin_uri\":\"https:\\/\\/www.advancedcustomfields.com\"},\"bamboo-tools\\/bamboo-tools.php\":{\"name\":\"Bamboo Tools\",\"version\":\"1.0.0\",\"plugin_uri\":\"\"},\"contact-form-7\\/wp-contact-form-7.php\":{\"name\":\"Contact Form 7\",\"version\":\"6.1.5\",\"plugin_uri\":\"https:\\/\\/contactform7.com\\/\"},\"cyr2lat\\/cyr-to-lat.php\":{\"name\":\"Cyr-To-Lat\",\"version\":\"6.6.0\",\"plugin_uri\":\"https:\\/\\/kagg.eu\\/cyr-to-lat\\/\"},\"simple-custom-post-order\\/simple-custom-post-order.php\":{\"name\":\"Simple Custom Post Order\",\"version\":\"2.6.0\",\"plugin_uri\":\"https:\\/\\/wordpress.org\\/plugins-wp\\/simple-custom-post-order\\/\"},\"wps-hide-login\\/wps-hide-login.php\":{\"name\":\"WPS Hide Login\",\"version\":\"1.9.18\",\"plugin_uri\":\"\"}},\"ui_field_groups\":\"0\",\"php_field_groups\":\"0\",\"json_field_groups\":\"7\",\"rest_field_groups\":\"0\",\"all_location_rules\":[\"page_template==page-about.php\",\"page_template==page-documents.php\",\"page_template==front-page.php\",\"post_type==documents\",\"options_page==contacts-settings\",\"post_type==services\",\"post_template!=front-page.php\"],\"field_groups_with_single_block_rule\":\"0\",\"field_groups_with_multiple_block_rules\":\"0\",\"field_groups_with_blocks_and_other_rules\":\"0\",\"number_of_fields_by_type\":{\"group\":7,\"tab\":2,\"textarea\":1},\"number_of_third_party_fields_by_type\":[],\"post_types_enabled\":true,\"ui_post_types\":\"7\",\"json_post_types\":\"0\",\"ui_taxonomies\":\"4\",\"json_taxonomies\":\"0\",\"ui_options_pages_enabled\":true,\"ui_options_pages\":\"0\",\"json_options_pages\":\"0\",\"php_options_pages\":\"1\",\"rest_api_format\":\"light\",\"registered_acf_blocks\":\"0\",\"blocks_per_api_version\":[],\"blocks_per_acf_block_version\":[],\"blocks_using_post_meta\":\"0\",\"blocks_using_auto_inline_editing\":\"0\",\"preload_blocks\":true,\"admin_ui_enabled\":true,\"field_type-modal_enabled\":true,\"field_settings_tabs_enabled\":false,\"shortcode_enabled\":false,\"registered_acf_forms\":\"0\",\"json_save_paths\":1,\"json_load_paths\":1,\"event_first_activated_pro\":1773743512,\"event_first_created_field_group\":1774011763,\"last_updated\":1774379866}','off'),
(201,'acf_version','6.7.1','auto'),
(202,'acf_pro_license','YToyOntzOjM6ImtleSI7czo3NjoiYjNKa1pYSmZhV1E5TVRNM01UTTRmSFI1Y0dVOVpHVjJaV3h2Y0dWeWZHUmhkR1U5TWpBeE9DMHdPQzB4TXlBeE1qb3dOVG8wTXc9PSI7czozOiJ1cmwiO3M6MTQ6Imh0dHA6Ly9pbXAubG9jIjt9','off'),
(203,'acf_pro_license_status','a:11:{s:6:\"status\";s:6:\"active\";s:7:\"created\";i:0;s:6:\"expiry\";i:0;s:4:\"name\";s:9:\"Developer\";s:8:\"lifetime\";b:1;s:8:\"refunded\";b:0;s:17:\"view_licenses_url\";s:62:\"https://www.advancedcustomfields.com/my-account/view-licenses/\";s:23:\"manage_subscription_url\";s:0:\"\";s:9:\"error_msg\";s:0:\"\";s:10:\"next_check\";i:1774466265;s:16:\"legacy_multisite\";b:1;}','on'),
(206,'whl_page','imp-admin-panel','auto'),
(207,'whl_redirect_admin','404','auto'),
(214,'dismissed_update_core','a:1:{s:8:\"6.9.4|uk\";b:1;}','off'),
(220,'scporder_install','1','auto'),
(221,'scporder_options','a:3:{s:7:\"objects\";a:4:{i:0;s:4:\"post\";i:1;s:4:\"page\";i:2;s:4:\"blog\";i:3;s:8:\"services\";}s:4:\"tags\";a:0:{}s:18:\"show_advanced_view\";s:0:\"\";}','auto'),
(232,'_transient_health-check-site-status-result','{\"good\":15,\"recommended\":4,\"critical\":1}','on'),
(248,'nav_menu_options','a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}','off'),
(379,'wpcf7','a:2:{s:7:\"version\";s:5:\"6.1.5\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1774112588;s:7:\"version\";s:5:\"6.1.5\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}','auto'),
(381,'secret_key','X>kW#q5; ;XN%n.#@*^b%6:5H)9+h$K#6.bR&g,3rB,|oRC1 *;y`R5&~`,`.whN','off'),
(413,'site_logo','138','auto'),
(418,'options_footer_logo','141','on'),
(419,'_options_footer_logo','field_69beef4b72758','on'),
(420,'options_footer_text','Ваш надійний юридичний радник у складних справах.','on'),
(421,'_options_footer_text','field_683465128791d','on'),
(422,'options_footer_socials','4','on'),
(423,'_options_footer_socials','field_683465188791e_field_6834652cf6284','on'),
(424,'options_footer_address','вул. Прикладна, 1, офіс 42\r\nм. Львів, 79000, Україна','on'),
(425,'_options_footer_address','field_contacts_address','on'),
(426,'options_footer_phones','1','on'),
(427,'_options_footer_phones','field_contacts_phones','on'),
(428,'options_footer_emails','1','on'),
(429,'_options_footer_emails','field_contacts_emails','on'),
(430,'options_footer','','on'),
(431,'_options_footer','field_69bef5afc4136','on'),
(432,'options_footer_phones_0_phone_number','+380 (00) 000-00-00','on'),
(433,'_options_footer_phones_0_phone_number','field_contacts_phone_number','on'),
(436,'options_footer_emails_0_email_address','info@implaw.com','on'),
(437,'_options_footer_emails_0_email_address','field_contacts_email_address','on'),
(440,'options_footer_socials_0_custom_icon','142','on'),
(441,'_options_footer_socials_0_custom_icon','field_6834663af6286','on'),
(442,'options_footer_socials_0_url','https://google.com','on'),
(443,'_options_footer_socials_0_url','field_68346a12f6287','on'),
(444,'options_footer_socials_1_custom_icon','143','on'),
(445,'_options_footer_socials_1_custom_icon','field_6834663af6286','on'),
(446,'options_footer_socials_1_url','https://google.com','on'),
(447,'_options_footer_socials_1_url','field_68346a12f6287','on'),
(448,'options_footer_socials_2_custom_icon','144','on'),
(449,'_options_footer_socials_2_custom_icon','field_6834663af6286','on'),
(450,'options_footer_socials_2_url','https://google.com','on'),
(451,'_options_footer_socials_2_url','field_68346a12f6287','on'),
(452,'options_footer_socials_3_custom_icon','145','on'),
(453,'_options_footer_socials_3_custom_icon','field_6834663af6286','on'),
(454,'options_footer_socials_3_url','https://google.com','on'),
(455,'_options_footer_socials_3_url','field_68346a12f6287','on'),
(481,'_transient_wp_styles_for_blocks','a:2:{s:4:\"hash\";s:32:\"a52b83aa2d51dbd4abfc827bc728d00d\";s:6:\"blocks\";a:6:{s:11:\"core/button\";s:0:\"\";s:14:\"core/site-logo\";s:0:\"\";s:18:\"core/post-template\";s:120:\":where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}\";s:18:\"core/term-template\";s:120:\":where(.wp-block-term-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-term-template.is-layout-grid){gap: 1.25em;}\";s:12:\"core/columns\";s:102:\":where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}\";s:14:\"core/pullquote\";s:69:\":root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}\";}}','on'),
(498,'blog_category_children','a:0:{}','auto'),
(517,'category_children','a:0:{}','auto'),
(522,'сategories_children','a:0:{}','auto'),
(525,'categories_children','a:0:{}','auto'),
(620,'recovery_mode_email_last_sent','1774272595','auto'),
(626,'options_consultation_title','Потрібна допомога у цій сфері?','on'),
(627,'_options_consultation_title','field_69c14fb9e9743','on'),
(628,'options_consultation_subtitle','Запишіться на первинну консультацію, щоб обговорити вашу\r\nситуацію та дізнатися можливі шляхи вирішення.','on'),
(629,'_options_consultation_subtitle','field_69c14fc6e9744','on'),
(630,'options_consultation_link','a:3:{s:5:\"title\";s:41:\"Замовити консультацію\";s:3:\"url\";s:24:\"http://imp.loc/contacts/\";s:6:\"target\";s:0:\"\";}','on'),
(631,'_options_consultation_link','field_69c14fd6e9745','on'),
(632,'options_consultation','','on'),
(633,'_options_consultation','field_69c14f92e9742','on'),
(652,'_transient_timeout_acf_plugin_updates','1774464833','off'),
(653,'_transient_acf_plugin_updates','a:5:{s:7:\"plugins\";a:0:{}s:9:\"no_update\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:12:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:5:\"6.7.1\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:5:\"6.9.1\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:64:\"https://connect.advancedcustomfields.com/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:66:\"https://connect.advancedcustomfields.com/assets/banner-772x250.jpg\";s:4:\"high\";s:67:\"https://connect.advancedcustomfields.com/assets/banner-1544x500.jpg\";}s:8:\"requires\";s:3:\"6.2\";s:12:\"requires_php\";s:3:\"7.4\";s:12:\"release_date\";s:8:\"20260303\";s:6:\"reason\";s:10:\"up_to_date\";}}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"6.7.1\";}}','off'),
(667,'_transient_timeout_acf_pro_validating_license','1774380764','off'),
(668,'_transient_acf_pro_validating_license','1','off'),
(671,'_site_transient_timeout_php_check_84bab1ffd8c4f8f9d81d62c8afdcab8a','1774984665','off'),
(672,'_site_transient_php_check_84bab1ffd8c4f8f9d81d62c8afdcab8a','a:5:{s:19:\"recommended_version\";s:3:\"8.3\";s:15:\"minimum_version\";s:6:\"7.2.24\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','off'),
(681,'_site_transient_timeout_available_translations','1774439583','off'),
(682,'_site_transient_available_translations','a:132:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-05-13 15:59:22\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"am\";a:8:{s:8:\"language\";s:2:\"am\";s:7:\"version\";s:6:\"6.0.11\";s:7:\"updated\";s:19:\"2022-09-29 20:43:49\";s:12:\"english_name\";s:7:\"Amharic\";s:11:\"native_name\";s:12:\"አማርኛ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.0.11/am.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"am\";i:2;s:3:\"amh\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ቀጥል\";}}s:3:\"arg\";a:8:{s:8:\"language\";s:3:\"arg\";s:7:\"version\";s:8:\"6.2-beta\";s:7:\"updated\";s:19:\"2022-09-22 16:46:56\";s:12:\"english_name\";s:9:\"Aragonese\";s:11:\"native_name\";s:9:\"Aragonés\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/6.2-beta/arg.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"an\";i:2;s:3:\"arg\";i:3;s:3:\"arg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continar\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"6.4.8\";s:7:\"updated\";s:19:\"2024-02-13 12:49:38\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.4.8/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"متابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:6:\"4.8.27\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.27/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-21 11:01:59\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"6.4.8\";s:7:\"updated\";s:19:\"2024-01-19 08:58:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.4.8/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.28\";s:7:\"updated\";s:19:\"2024-12-26 00:37:42\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.28/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-02 09:00:09\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-07 06:54:04\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:28:\"চালিয়ে যান\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2020-10-30 03:24:38\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.8-beta/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:33:\"མུ་མཐུད་དུ།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2023-02-22 20:45:53\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.2.9/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-06 07:54:57\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-09 10:52:02\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-20 11:38:29\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-06 10:11:50\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-10-23 12:01:47\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-25 00:18:51\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-25 00:18:21\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/6.9.4/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-11-28 08:11:27\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-11-28 08:08:17\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/6.9.4/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dsb\";a:8:{s:8:\"language\";s:3:\"dsb\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2022-07-16 12:13:09\";s:12:\"english_name\";s:13:\"Lower Sorbian\";s:11:\"native_name\";s:16:\"Dolnoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.2.9/dsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"dsb\";i:3;s:3:\"dsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Dalej\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-02 11:19:29\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-11-25 13:30:15\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-18 19:42:42\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-12-24 12:51:19\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-24 14:35:45\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-12-30 11:47:57\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-18 08:16:53\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-10 15:51:08\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-18 00:34:47\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-03 16:11:04\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-22 20:34:00\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:3:\"6.9\";s:7:\"updated\";s:19:\"2025-10-01 22:54:47\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.9/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2024-10-16 21:04:12\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/6.9-RC/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"6.4.8\";s:7:\"updated\";s:19:\"2023-10-16 16:00:04\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.4.8/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_EC\";a:8:{s:8:\"language\";s:5:\"es_EC\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2023-04-21 13:32:10\";s:12:\"english_name\";s:17:\"Spanish (Ecuador)\";s:11:\"native_name\";s:19:\"Español de Ecuador\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.2.9/es_EC.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_DO\";a:8:{s:8:\"language\";s:5:\"es_DO\";s:7:\"version\";s:6:\"5.8.13\";s:7:\"updated\";s:19:\"2021-10-08 14:32:50\";s:12:\"english_name\";s:28:\"Spanish (Dominican Republic)\";s:11:\"native_name\";s:33:\"Español de República Dominicana\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.8.13/es_DO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-31 18:33:26\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PR\";a:8:{s:8:\"language\";s:5:\"es_PR\";s:7:\"version\";s:6:\"5.4.19\";s:7:\"updated\";s:19:\"2020-04-29 15:36:59\";s:12:\"english_name\";s:21:\"Spanish (Puerto Rico)\";s:11:\"native_name\";s:23:\"Español de Puerto Rico\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.4.19/es_PR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:6:\"5.2.23\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.23/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-11 00:33:09\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"6.5.7\";s:7:\"updated\";s:19:\"2024-06-06 09:50:37\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.5.7/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2025-11-05 21:53:17\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.9-RC/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-12-25 18:17:43\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"fa_AF\";a:8:{s:8:\"language\";s:5:\"fa_AF\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2025-02-14 17:29:08\";s:12:\"english_name\";s:21:\"Persian (Afghanistan)\";s:11:\"native_name\";s:31:\"(فارسی (افغانستان\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/6.9-RC/fa_AF.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-03 18:15:59\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-10-03 04:54:28\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-13 13:01:53\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"6.5.8\";s:7:\"updated\";s:19:\"2024-02-01 23:56:53\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.5.8/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:6:\"4.8.27\";s:7:\"updated\";s:19:\"2025-12-20 19:08:53\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.27/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"fy\";a:8:{s:8:\"language\";s:2:\"fy\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2025-10-21 16:35:04\";s:12:\"english_name\";s:7:\"Frisian\";s:11:\"native_name\";s:5:\"Frysk\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.2.9/fy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fy\";i:2;s:3:\"fry\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Trochgean\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-01 13:15:26\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-16 17:02:55\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ચાલુ રાખો\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:6:\"4.4.34\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.4.34/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2024-05-04 18:39:24\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.2.9/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"6.4.8\";s:7:\"updated\";s:19:\"2025-02-06 05:17:11\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.4.8/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"जारी रखें\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-01-31 09:13:17\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2023-02-22 17:37:32\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.2.9/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-01-26 09:03:23\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-11 02:15:15\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.9.28\";s:7:\"updated\";s:19:\"2018-12-11 10:40:02\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.28/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-01 12:46:02\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-13 13:31:48\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"次へ\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:6:\"4.9.28\";s:7:\"updated\";s:19:\"2019-02-16 23:58:56\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.28/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-20 10:55:32\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2023-07-05 11:40:39\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.2.9/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2024-07-18 02:49:24\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.9-RC/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:6:\"5.2.23\";s:7:\"updated\";s:19:\"2019-06-10 16:18:28\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.23/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-02 11:49:59\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರಿಸು\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-25 02:38:01\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-24 14:14:21\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.9.4/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:3:\"kir\";a:8:{s:8:\"language\";s:3:\"kir\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-01-01 21:45:29\";s:12:\"english_name\";s:6:\"Kyrgyz\";s:11:\"native_name\";s:16:\"Кыргызча\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.9.4/kir.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ky\";i:2;s:3:\"kir\";i:3;s:3:\"kir\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Улантуу\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-23 01:10:05\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2025-09-27 20:51:17\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/6.9-RC/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-20 20:55:46\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:6:\"6.0.11\";s:7:\"updated\";s:19:\"2022-10-01 09:23:52\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/6.0.11/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-23 15:49:12\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"6.5.8\";s:7:\"updated\";s:19:\"2024-06-20 17:22:06\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.5.8/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-25 15:07:24\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"5.5.18\";s:7:\"updated\";s:19:\"2022-03-11 13:52:22\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.5.18/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.2.39\";s:7:\"updated\";s:19:\"2017-12-26 11:57:10\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.39/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-03 15:03:26\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2025-11-07 08:26:32\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/6.9-RC/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-06 07:16:45\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-16 09:53:11\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-01-29 08:00:04\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/6.9.4/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-03-18 10:59:16\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:6:\"4.8.27\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.27/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:15:\"Panjabi (India)\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-07 22:09:59\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.3.35\";s:7:\"updated\";s:19:\"2015-12-02 21:41:29\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.3.35/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-04 09:12:12\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-13 21:17:41\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"6.4.8\";s:7:\"updated\";s:19:\"2023-08-21 12:15:00\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.4.8/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-04 09:13:24\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/6.9.4/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-23 19:27:53\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-14 06:19:08\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:6:\"5.4.19\";s:7:\"updated\";s:19:\"2020-07-07 01:53:37\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/5.4.19/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:3:\"snd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-25 08:52:18\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:6:\"6.9-RC\";s:7:\"updated\";s:19:\"2025-04-24 16:58:02\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/6.9-RC/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-10-29 11:19:02\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-14 20:39:21\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2025-12-03 15:37:44\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-16 12:21:00\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-21 11:17:30\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:5:\"ta_LK\";a:8:{s:8:\"language\";s:5:\"ta_LK\";s:7:\"version\";s:6:\"4.2.39\";s:7:\"updated\";s:19:\"2015-12-03 01:07:44\";s:12:\"english_name\";s:17:\"Tamil (Sri Lanka)\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.39/ta_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"தொடர்க\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:6:\"5.8.13\";s:7:\"updated\";s:19:\"2022-06-08 04:30:30\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.8.13/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-26 04:01:56\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-10 21:54:48\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-01-29 23:09:01\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:3:\"6.8\";s:7:\"updated\";s:19:\"2025-04-18 21:10:00\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/6.8/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:6:\"5.4.19\";s:7:\"updated\";s:19:\"2020-04-09 11:17:33\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.4.19/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:8:\"5.8-beta\";s:7:\"updated\";s:19:\"2021-02-28 12:02:22\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.8-beta/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-22 14:30:31\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/6.9.4/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:3:\"yor\";a:8:{s:8:\"language\";s:3:\"yor\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-03-17 19:42:05\";s:12:\"english_name\";s:6:\"Yoruba\";s:11:\"native_name\";s:8:\"Yorùbá\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/6.9.4/yor.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"yo\";i:2;s:3:\"yor\";i:3;s:3:\"yor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"Tẹ̀síwájú si\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-01-06 20:16:48\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"6.2.9\";s:7:\"updated\";s:19:\"2022-07-15 15:25:03\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:12:\"香港中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.2.9/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"6.9.4\";s:7:\"updated\";s:19:\"2026-02-11 16:22:59\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/6.9.4/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}','off'),
(686,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.9.4.zip\";s:6:\"locale\";s:2:\"uk\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-6.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-6.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-6.9.4-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.9.4\";s:7:\"version\";s:5:\"6.9.4\";s:11:\"php_version\";s:6:\"7.2.24\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1774428785;s:15:\"version_checked\";s:5:\"6.9.4\";s:12:\"translations\";a:0:{}}','off'),
(687,'_site_transient_update_themes','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1774428785;s:7:\"checked\";a:1:{s:6:\"bamboo\";s:3:\"3.0\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}','off'),
(688,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1774428786;s:8:\"response\";a:0:{}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"6.1.5\";s:7:\"updated\";s:19:\"2025-12-27 13:54:22\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/6.1.5/uk.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:4:{s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"6.1.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.6.1.5.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.7\";}s:22:\"cyr2lat/cyr-to-lat.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:21:\"w.org/plugins/cyr2lat\";s:4:\"slug\";s:7:\"cyr2lat\";s:6:\"plugin\";s:22:\"cyr2lat/cyr-to-lat.php\";s:11:\"new_version\";s:5:\"6.6.0\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr2lat/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/cyr2lat.6.6.0.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:52:\"https://ps.w.org/cyr2lat/assets/icon.svg?rev=2834364\";s:3:\"svg\";s:52:\"https://ps.w.org/cyr2lat/assets/icon.svg?rev=2834364\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/cyr2lat/assets/banner-1544x500.png?rev=2434252\";s:2:\"1x\";s:62:\"https://ps.w.org/cyr2lat/assets/banner-772x250.png?rev=2434252\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.3\";}s:53:\"simple-custom-post-order/simple-custom-post-order.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:38:\"w.org/plugins/simple-custom-post-order\";s:4:\"slug\";s:24:\"simple-custom-post-order\";s:6:\"plugin\";s:53:\"simple-custom-post-order/simple-custom-post-order.php\";s:11:\"new_version\";s:5:\"2.6.0\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/simple-custom-post-order/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/simple-custom-post-order.2.6.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/simple-custom-post-order/assets/icon-256x256.jpg?rev=2969435\";s:2:\"1x\";s:77:\"https://ps.w.org/simple-custom-post-order/assets/icon-256x256.jpg?rev=2969435\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/simple-custom-post-order/assets/banner-772x250.jpg?rev=2969435\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"6.2\";}s:33:\"wps-hide-login/wps-hide-login.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:28:\"w.org/plugins/wps-hide-login\";s:4:\"slug\";s:14:\"wps-hide-login\";s:6:\"plugin\";s:33:\"wps-hide-login/wps-hide-login.php\";s:11:\"new_version\";s:6:\"1.9.18\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wps-hide-login/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/wps-hide-login.1.9.18.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/wps-hide-login/assets/icon-256x256.png?rev=1820667\";s:2:\"1x\";s:67:\"https://ps.w.org/wps-hide-login/assets/icon-128x128.png?rev=1820667\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/wps-hide-login/assets/banner-1544x500.jpg?rev=1820667\";s:2:\"1x\";s:69:\"https://ps.w.org/wps-hide-login/assets/banner-772x250.jpg?rev=1820667\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.1\";}}s:7:\"checked\";a:6:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"6.7.1\";s:29:\"bamboo-tools/bamboo-tools.php\";s:5:\"1.0.0\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"6.1.5\";s:22:\"cyr2lat/cyr-to-lat.php\";s:5:\"6.6.0\";s:53:\"simple-custom-post-order/simple-custom-post-order.php\";s:5:\"2.6.0\";s:33:\"wps-hide-login/wps-hide-login.php\";s:6:\"1.9.18\";}}','off'),
(692,'_site_transient_timeout_wp_theme_files_patterns-bb2f928212a13be5263686ff1878cc2d','1774432570','off'),
(693,'_site_transient_wp_theme_files_patterns-bb2f928212a13be5263686ff1878cc2d','a:2:{s:7:\"version\";s:3:\"1.0\";s:8:\"patterns\";a:0:{}}','off'),
(694,'_site_transient_timeout_theme_roots','1774432547','off'),
(695,'_site_transient_theme_roots','a:1:{s:6:\"bamboo\";s:7:\"/themes\";}','off');
/*!40000 ALTER TABLE `bb_options` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_postmeta`
--

DROP TABLE IF EXISTS `bb_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=529 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_postmeta`
--

LOCK TABLES `bb_postmeta` WRITE;
/*!40000 ALTER TABLE `bb_postmeta` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_postmeta` VALUES
(3,5,'_edit_lock','1773684304:1'),
(6,6,'_edit_lock','1773684173:1'),
(9,6,'_wp_trash_meta_status','publish'),
(10,6,'_wp_trash_meta_time','1773684320'),
(11,6,'_wp_desired_post_slug','sdfsdf3434'),
(12,5,'_wp_trash_meta_status','publish'),
(13,5,'_wp_trash_meta_time','1773684321'),
(14,5,'_wp_desired_post_slug','sdfsdf'),
(15,7,'_edit_lock','1774270642:1'),
(16,7,'_edit_last','1'),
(17,7,'_wp_page_template','front-page.php'),
(18,8,'_wp_trash_meta_status','publish'),
(19,8,'_wp_trash_meta_time','1773684430'),
(21,10,'_edit_lock','1774270972:1'),
(22,10,'_wp_page_template','page-about.php'),
(24,12,'_wp_page_template','page-services.php'),
(25,13,'_wp_page_template','page-blog.php'),
(26,14,'_wp_page_template','page-documents.php'),
(27,15,'_wp_page_template','page-contacts.php'),
(29,13,'_edit_lock','1774271333:1'),
(30,17,'_menu_item_type','post_type'),
(31,17,'_menu_item_menu_item_parent','0'),
(32,17,'_menu_item_object_id','15'),
(33,17,'_menu_item_object','page'),
(34,17,'_menu_item_target',''),
(35,17,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(36,17,'_menu_item_xfn',''),
(37,17,'_menu_item_url',''),
(39,18,'_menu_item_type','post_type'),
(40,18,'_menu_item_menu_item_parent','0'),
(41,18,'_menu_item_object_id','14'),
(42,18,'_menu_item_object','page'),
(43,18,'_menu_item_target',''),
(44,18,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(45,18,'_menu_item_xfn',''),
(46,18,'_menu_item_url',''),
(48,19,'_menu_item_type','post_type'),
(49,19,'_menu_item_menu_item_parent','0'),
(50,19,'_menu_item_object_id','13'),
(51,19,'_menu_item_object','page'),
(52,19,'_menu_item_target',''),
(53,19,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(54,19,'_menu_item_xfn',''),
(55,19,'_menu_item_url',''),
(57,20,'_menu_item_type','post_type'),
(58,20,'_menu_item_menu_item_parent','0'),
(59,20,'_menu_item_object_id','12'),
(60,20,'_menu_item_object','page'),
(61,20,'_menu_item_target',''),
(62,20,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(63,20,'_menu_item_xfn',''),
(64,20,'_menu_item_url',''),
(66,21,'_menu_item_type','post_type'),
(67,21,'_menu_item_menu_item_parent','0'),
(68,21,'_menu_item_object_id','10'),
(69,21,'_menu_item_object','page'),
(70,21,'_menu_item_target',''),
(71,21,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(72,21,'_menu_item_xfn',''),
(73,21,'_menu_item_url',''),
(75,22,'_menu_item_type','custom'),
(76,22,'_menu_item_menu_item_parent','0'),
(77,22,'_menu_item_object_id','22'),
(78,22,'_menu_item_object','custom'),
(79,22,'_menu_item_target',''),
(80,22,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(81,22,'_menu_item_xfn',''),
(82,22,'_menu_item_url','/'),
(84,23,'_menu_item_type','post_type'),
(85,23,'_menu_item_menu_item_parent','0'),
(86,23,'_menu_item_object_id','15'),
(87,23,'_menu_item_object','page'),
(88,23,'_menu_item_target',''),
(89,23,'_menu_item_classes','a:3:{i:0;s:5:\"order\";i:1;s:3:\"cta\";i:2;s:4:\"gold\";}'),
(90,23,'_menu_item_xfn',''),
(91,23,'_menu_item_url',''),
(93,12,'_edit_lock','1774271222:1'),
(94,24,'_edit_lock','1773854852:1'),
(95,25,'_edit_lock','1774272492:1'),
(99,12,'_edit_last','1'),
(120,64,'_edit_lock','1774276484:1'),
(121,64,'_edit_last','1'),
(122,7,'page_content_intro-section_title','Адвокатське Бюро\r\n«Ігор Мельник та Партнери»'),
(123,7,'_page_content_intro-section_title','field_695525281e73d'),
(124,7,'page_content_intro-section_supertitle','Ваш надійний юридичний радник у складних справах.'),
(125,7,'_page_content_intro-section_supertitle','field_695522ae1e73c'),
(126,7,'page_content_intro-section_button','a:3:{s:5:\"title\";s:41:\"Замовити консультацію\";s:3:\"url\";s:24:\"http://imp.loc/contacts/\";s:6:\"target\";s:0:\"\";}'),
(127,7,'_page_content_intro-section_button','field_695525bfd2c0d'),
(128,7,'page_content_intro-section_button_2','a:3:{s:5:\"title\";s:13:\"Про нас\";s:3:\"url\";s:24:\"http://imp.loc/about-us/\";s:6:\"target\";s:0:\"\";}'),
(129,7,'_page_content_intro-section_button_2','field_69bd4684f70b7'),
(130,7,'page_content_intro-section',''),
(131,7,'_page_content_intro-section','field_695522a01e73b'),
(132,7,'page_content_practices-section_title','Ключові практики'),
(133,7,'_page_content_practices-section_title','field_695530001a002'),
(134,7,'page_content_practices-section_items','a:3:{i:0;s:2:\"25\";i:1;s:3:\"156\";i:2;s:3:\"164\";}'),
(135,7,'_page_content_practices-section_items','field_695530001a003'),
(136,7,'page_content_practices-section_button','a:3:{s:5:\"title\";s:21:\"Всі послуги\";s:3:\"url\";s:24:\"http://imp.loc/services/\";s:6:\"target\";s:0:\"\";}'),
(137,7,'_page_content_practices-section_button','field_695530001a008'),
(138,7,'page_content_practices-section',''),
(139,7,'_page_content_practices-section','field_695530001a001'),
(140,7,'page_content_advantages-section_title','Чому обирають нас'),
(141,7,'_page_content_advantages-section_title','field_695530001b002'),
(166,7,'page_content_advantages-section_items','4'),
(167,7,'_page_content_advantages-section_items','field_695530001b003'),
(168,7,'page_content_advantages-section',''),
(169,7,'_page_content_advantages-section','field_695530001b001'),
(170,7,'page_content_latest-news-section_title','Останні новини'),
(171,7,'_page_content_latest-news-section_title','field_695530001c002'),
(172,7,'page_content_latest-news-section_button','a:3:{s:5:\"title\";s:8:\"Блог\";s:3:\"url\";s:20:\"http://imp.loc/blog/\";s:6:\"target\";s:0:\"\";}'),
(173,7,'_page_content_latest-news-section_button','field_695530001c003'),
(174,7,'page_content_latest-news-section',''),
(175,7,'_page_content_latest-news-section','field_695530001c001'),
(176,7,'page_content',''),
(177,7,'_page_content','field_695520e5dcba2'),
(178,89,'_form','<p class=\"form-title font-28\">Надіслати запит</p>\n<label>\n  <span class=\"placeholder\">Ваше ім\'я</span>\n  [text* your_name minlength:3 maxlength:40 placeholder \"Ваше ім\'я\" ]\n</label>\n<label>\n  <span class=\"placeholder\">E-mail</span>\n  [email your_email maxlength:40 placeholder \"Ваш E-mail\"]\n</label>\n<label>\n  <span class=\"placeholder\">Короткий опис</span>\n  [textarea user_message 10x3 placeholder \"Опишіть суть вашого питання...\"]\n</label>\n<button class=\"cta gold\">Надіслати</button>'),
(179,89,'_mail','a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:32:\"[_site_title] від [your_name]\";s:6:\"sender\";s:33:\"[_site_title] <wordpress@imp.loc>\";s:9:\"recipient\";s:19:\"[_site_admin_email]\";s:4:\"body\";s:250:\"Від: [your_name]\nEmail: [your_email]\nПовідомлення: \n[user_message]\n\n\n\nЦе сповіщення про те, що на вашому вебсайті було надіслано контактну форму ([_site_title] [_site_url]).\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:1;}'),
(180,89,'_mail_2','a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:30:\"[_site_title] \"[your-subject]\"\";s:6:\"sender\";s:33:\"[_site_title] <wordpress@imp.loc>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:220:\"Message Body:\n[your-message]\n\n-- \nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.\";s:18:\"additional_headers\";s:29:\"Reply-To: [_site_admin_email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:1;}'),
(181,89,'_messages','a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:27:\"Please fill out this field.\";s:16:\"invalid_too_long\";s:32:\"This field has a too long input.\";s:17:\"invalid_too_short\";s:33:\"This field has a too short input.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:31:\"The uploaded file is too large.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:12:\"invalid_date\";s:41:\"Please enter a date in YYYY-MM-DD format.\";s:14:\"date_too_early\";s:32:\"This field has a too early date.\";s:13:\"date_too_late\";s:31:\"This field has a too late date.\";s:14:\"invalid_number\";s:22:\"Please enter a number.\";s:16:\"number_too_small\";s:34:\"This field has a too small number.\";s:16:\"number_too_large\";s:34:\"This field has a too large number.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:30:\"Please enter an email address.\";s:11:\"invalid_url\";s:19:\"Please enter a URL.\";s:11:\"invalid_tel\";s:32:\"Please enter a telephone number.\";}'),
(182,89,'_additional_settings',''),
(183,89,'_locale','uk'),
(184,89,'_hash','01eca0dd891857a7d0a9006529ff90834c8e1b45520cb6b0e5f51d0f4a160040'),
(199,90,'_menu_item_type','custom'),
(200,90,'_menu_item_menu_item_parent','0'),
(201,90,'_menu_item_object_id','90'),
(202,90,'_menu_item_object','custom'),
(203,90,'_menu_item_target',''),
(204,90,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(205,90,'_menu_item_xfn',''),
(206,90,'_menu_item_url','#'),
(208,91,'_menu_item_type','post_type'),
(209,91,'_menu_item_menu_item_parent','90'),
(210,91,'_menu_item_object_id','15'),
(211,91,'_menu_item_object','page'),
(212,91,'_menu_item_target',''),
(213,91,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(214,91,'_menu_item_xfn',''),
(215,91,'_menu_item_url',''),
(217,92,'_menu_item_type','post_type'),
(218,92,'_menu_item_menu_item_parent','90'),
(219,92,'_menu_item_object_id','14'),
(220,92,'_menu_item_object','page'),
(221,92,'_menu_item_target',''),
(222,92,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(223,92,'_menu_item_xfn',''),
(224,92,'_menu_item_url',''),
(226,93,'_menu_item_type','post_type'),
(227,93,'_menu_item_menu_item_parent','90'),
(228,93,'_menu_item_object_id','13'),
(229,93,'_menu_item_object','page'),
(230,93,'_menu_item_target',''),
(231,93,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(232,93,'_menu_item_xfn',''),
(233,93,'_menu_item_url',''),
(235,94,'_menu_item_type','post_type'),
(236,94,'_menu_item_menu_item_parent','90'),
(237,94,'_menu_item_object_id','12'),
(238,94,'_menu_item_object','page'),
(239,94,'_menu_item_target',''),
(240,94,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(241,94,'_menu_item_xfn',''),
(242,94,'_menu_item_url',''),
(244,95,'_menu_item_type','post_type'),
(245,95,'_menu_item_menu_item_parent','90'),
(246,95,'_menu_item_object_id','10'),
(247,95,'_menu_item_object','page'),
(248,95,'_menu_item_target',''),
(249,95,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(250,95,'_menu_item_xfn',''),
(251,95,'_menu_item_url',''),
(253,96,'_menu_item_type','custom'),
(254,96,'_menu_item_menu_item_parent','0'),
(255,96,'_menu_item_object_id','96'),
(256,96,'_menu_item_object','custom'),
(257,96,'_menu_item_target',''),
(258,96,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(259,96,'_menu_item_xfn',''),
(260,96,'_menu_item_url','#'),
(262,97,'_menu_item_type','post_type'),
(263,97,'_menu_item_menu_item_parent','96'),
(264,97,'_menu_item_object_id','25'),
(265,97,'_menu_item_object','services'),
(266,97,'_menu_item_target',''),
(267,97,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),
(268,97,'_menu_item_xfn',''),
(269,97,'_menu_item_url',''),
(285,119,'_edit_lock','1774276728:1'),
(286,119,'_edit_last','1'),
(289,131,'_wp_attached_file','2026/03/favicon.png'),
(290,131,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:19:\"2026/03/favicon.png\";s:8:\"filesize\";i:3633;s:5:\"sizes\";a:2:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4148;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"favicon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1802;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(291,132,'_wp_attached_file','2026/03/cropped-favicon.png'),
(292,132,'_wp_attachment_context','site-icon'),
(293,132,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:27:\"2026/03/cropped-favicon.png\";s:8:\"filesize\";i:3775;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4148;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1802;}s:13:\"site_icon-270\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3465;}s:13:\"site_icon-192\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2093;}s:13:\"site_icon-180\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2150;}s:12:\"site_icon-32\";a:5:{s:4:\"file\";s:25:\"cropped-favicon-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:433;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(294,133,'_wp_attached_file','2026/03/cropped-favicon-1.png'),
(295,133,'_wp_attachment_context','site-icon'),
(296,133,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:29:\"2026/03/cropped-favicon-1.png\";s:8:\"filesize\";i:3775;s:5:\"sizes\";a:6:{s:6:\"medium\";a:5:{s:4:\"file\";s:29:\"cropped-favicon-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:4148;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:29:\"cropped-favicon-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:1802;}s:13:\"site_icon-270\";a:5:{s:4:\"file\";s:29:\"cropped-favicon-1-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:3465;}s:13:\"site_icon-192\";a:5:{s:4:\"file\";s:29:\"cropped-favicon-1-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2093;}s:13:\"site_icon-180\";a:5:{s:4:\"file\";s:29:\"cropped-favicon-1-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2150;}s:12:\"site_icon-32\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-1-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:433;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(297,134,'_edit_lock','1774121787:1'),
(300,134,'_wp_trash_meta_status','publish'),
(301,134,'_wp_trash_meta_time','1774121795'),
(302,136,'_wp_trash_meta_status','publish'),
(303,136,'_wp_trash_meta_time','1774121815'),
(306,138,'_wp_attached_file','2026/03/logo-colored.svg'),
(307,138,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:761;}'),
(308,139,'_wp_trash_meta_status','publish'),
(309,139,'_wp_trash_meta_time','1774122046'),
(310,141,'_wp_attached_file','2026/03/logo-long.svg'),
(311,141,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:16548;}'),
(312,141,'_wp_attachment_image_alt','Лого Адвокатське Бюро «Ігор Мельник та Партнери»'),
(313,142,'_wp_attached_file','2026/03/whatsapp.svg'),
(314,142,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:1091;}'),
(315,143,'_wp_attached_file','2026/03/facebook.svg'),
(316,143,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:378;}'),
(317,144,'_wp_attached_file','2026/03/instagram.svg'),
(318,144,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:819;}'),
(319,145,'_wp_attached_file','2026/03/telegram.svg'),
(320,145,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:635;}'),
(323,147,'_edit_lock','1774264201:1'),
(330,152,'_edit_lock','1774175683:1'),
(331,153,'_edit_lock','1774264068:1'),
(339,156,'_edit_lock','1774190872:1'),
(340,157,'_edit_last','1'),
(341,157,'_edit_lock','1774190837:1'),
(342,25,'_edit_last','1'),
(343,25,'_content','Наша22 компанія пропонує широкий спектр послуг у галузі <strong>корпоративного права</strong>, орієнтуючись на потреби бізнесу. Ми забезпечуємо ефективну юридичну підтримку на кожному етапі розвитку вашої компанії, від її створення до вирішення складних корпоративних спорів.\r\n\r\n<!-- Підрозділ \"Створення бізнесу\" -->\r\n<h2>Створення бізнесу</h2>\r\nДопомагаємо у реєстрації компаній, виборі правової форми та розробці необхідної документації для ведення бізнесу. Наші юристи допоможуть вам пройти всі етапи від реєстрації до запуску бізнесу на ринку.\r\n<h3>Послуги:</h3>\r\n<ul>\r\n 	<li>Реєстрація юридичних осіб</li>\r\n 	<li>Розробка статутних документів</li>\r\n 	<li>Підготовка договорів та угод</li>\r\n</ul>\r\n<!-- Підрозділ \"Реорганізація бізнесу\" -->\r\n<h2>Реорганізація бізнесу</h2>\r\nУ разі необхідності змін у структурі вашої компанії, ми надаємо послуги з реорганізації бізнесу, включаючи злиття, поділ або трансформацію юридичних осіб.\r\n<h3>Основні аспекти реорганізації:</h3>\r\n<ul>\r\n 	<li>Підготовка юридичних документів для реорганізації</li>\r\n 	<li>Юридичний супровід злиття та поглинання</li>\r\n 	<li>Консультації з питань змін у корпоративній структурі</li>\r\n</ul>\r\n<!-- Підрозділ \"Вирішення корпоративних спорів\" -->\r\n<h2>Вирішення корпоративних спорів</h2>\r\nНаші адвокати мають досвід у вирішенні корпоративних спорів, що виникають між акціонерами, партнерами чи іншими учасниками бізнесу. Ми використовуємо ефективні стратегії для вирішення конфліктів мирним шляхом або через судові процеси.\r\n<h3>Методи вирішення спорів:</h3>\r\n<ul>\r\n 	<li>Медіація</li>\r\n 	<li>Арбітраж</li>\r\n 	<li>Представництво в суді</li>\r\n</ul>\r\n<!-- Підрозділ \"Чому обирають нас?\" -->\r\n<h2>Чому обирають нас?</h2>\r\nНаші юристи мають багаторічний досвід роботи в галузі корпоративного права та можуть надати висококваліфіковану допомогу у всіх аспектах ведення бізнесу. Ми орієнтовані на досягнення найкращих результатів для наших клієнтів.'),
(344,25,'__content','field_69bffb6300a31'),
(345,25,'single-service_content',''),
(346,25,'_single-service_content','field_69bffb6300a31'),
(347,25,'single-service',''),
(348,25,'_single-service','field_69bffb5000a30'),
(349,25,'single-service_icon','162'),
(350,25,'_single-service_icon','field_69bffeb25599b'),
(351,156,'_edit_last','1'),
(352,156,'single-service_icon','163'),
(353,156,'_single-service_icon','field_69bffeb25599b'),
(354,156,'single-service_content','Наша компанія надає комплексну правову допомогу в сфері <strong>господарського права</strong>, охоплюючи всі етапи ведення бізнесу, від укладання договорів до вирішення господарських суперечок. Ми допомагаємо підприємцям, компаніям та організаціям досягти успіху в складному правовому середовищі.\r\n<h2>Укладання господарських договорів</h2>\r\nМи надаємо послуги з укладання та супроводження різноманітних господарських договорів, забезпечуючи юридичну підтримку на кожному етапі:\r\n<ul>\r\n 	<li>Підготовка договорів</li>\r\n 	<li>Оцінка ризиків</li>\r\n 	<li>Перевірка та аналіз контрактів</li>\r\n</ul>\r\n<h2>Представництво в судових спорах</h2>\r\nНаші адвокати мають великий досвід у веденні судових справ в господарських судах. Ми надаємо допомогу в таких питаннях:\r\n<ul>\r\n 	<li>Спори з постачальниками</li>\r\n 	<li>Конфлікти з контрагентами</li>\r\n 	<li>Порушення договірних зобов\'язань</li>\r\n</ul>\r\n<h2>Ліцензування та сертифікація</h2>\r\nМи допомагаємо в отриманні ліцензій та сертифікатів для ведення господарської діяльності в різних сферах:\r\n<ul>\r\n 	<li>Оформлення ліцензій для різних видів діяльності</li>\r\n 	<li>Консультації щодо вимог законодавства</li>\r\n 	<li>Супровід процедур сертифікації</li>\r\n</ul>\r\n<h2>Консультації з питань господарської діяльності</h2>\r\nНаші юристи готові надати консультації з усіх аспектів господарського права, включаючи:\r\n<ul>\r\n 	<li>Вибір оптимальної організаційно-правової форми</li>\r\n 	<li>Реєстрація підприємств</li>\r\n 	<li>Оцінка правових ризиків</li>\r\n</ul>\r\n<h2>Чому обирають нас?</h2>\r\nНаші адвокати мають глибоке розуміння господарського права та досвід у вирішенні складних юридичних питань. Ми прагнемо забезпечити нашим клієнтам надійну правову підтримку, що допоможе розвивати їхній бізнес без юридичних ризиків.'),
(355,156,'_single-service_content','field_69bffb6300a31'),
(356,156,'single-service',''),
(357,156,'_single-service','field_69bffb5000a30'),
(360,162,'_wp_attached_file','2026/03/sercive-1.svg'),
(361,162,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:710;}'),
(362,163,'_wp_attached_file','2026/03/sercive-2.svg'),
(363,163,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:974;}'),
(364,164,'_edit_last','1'),
(365,164,'_edit_lock','1774190916:1'),
(366,165,'_wp_attached_file','2026/03/sercive-3.svg'),
(367,165,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:952;}'),
(368,164,'single-service_icon','165'),
(369,164,'_single-service_icon','field_69bffeb25599b'),
(370,164,'single-service_content','В рамках практики \"<strong>судове представництво</strong>\" наше адвокатське бюро пропонує комплексний підхід до вирішення задач клієнта. Ми розуміємо, що кожна ситуація унікальна, тому формуємо стратегію виключно на основі глибокого аналізу специфіки вашого бізнесу чи особистої ситуації.\r\n\r\nНаш багаторічний досвід дозволяє ефективно захищати інтереси клієнтів, мінімізувати юридичні ризики та сприяти досягненню поставлених комерційних цілей у найкоротші терміни.'),
(371,164,'_single-service_content','field_69bffb6300a31'),
(372,164,'single-service',''),
(373,164,'_single-service','field_69bffb5000a30'),
(374,7,'page_content_advantages-section_items_0_icon','166'),
(375,7,'_page_content_advantages-section_items_0_icon','field_695530001b004'),
(376,7,'page_content_advantages-section_items_0_g_title','Досвід у складних справах'),
(377,7,'_page_content_advantages-section_items_0_g_title','field_695530001b005'),
(378,7,'page_content_advantages-section_items_0_g_text','Ми успішно вирішуємо найскладніші юридичні завдання.'),
(379,7,'_page_content_advantages-section_items_0_g_text','field_695530001b006'),
(380,7,'page_content_advantages-section_items_0_g',''),
(381,7,'_page_content_advantages-section_items_0_g','field_69bd477a37d4a'),
(382,7,'page_content_advantages-section_items_1_icon','167'),
(383,7,'_page_content_advantages-section_items_1_icon','field_695530001b004'),
(384,7,'page_content_advantages-section_items_1_g_title','Міжнародні контракти'),
(385,7,'_page_content_advantages-section_items_1_g_title','field_695530001b005'),
(386,7,'page_content_advantages-section_items_1_g_text','Супровід зовнішньоекономічної діяльності.'),
(387,7,'_page_content_advantages-section_items_1_g_text','field_695530001b006'),
(388,7,'page_content_advantages-section_items_1_g',''),
(389,7,'_page_content_advantages-section_items_1_g','field_69bd477a37d4a'),
(390,7,'page_content_advantages-section_items_2_icon','168'),
(391,7,'_page_content_advantages-section_items_2_icon','field_695530001b004'),
(392,7,'page_content_advantages-section_items_2_g_title','Індивідуальний підхід'),
(393,7,'_page_content_advantages-section_items_2_g_title','field_695530001b005'),
(394,7,'page_content_advantages-section_items_2_g_text','Глибоке занурення в специфіку бізнесу клієнта.'),
(395,7,'_page_content_advantages-section_items_2_g_text','field_695530001b006'),
(396,7,'page_content_advantages-section_items_2_g',''),
(397,7,'_page_content_advantages-section_items_2_g','field_69bd477a37d4a'),
(398,7,'page_content_advantages-section_items_3_icon','169'),
(399,7,'_page_content_advantages-section_items_3_icon','field_695530001b004'),
(400,7,'page_content_advantages-section_items_3_g_title','Конфіденційність'),
(401,7,'_page_content_advantages-section_items_3_g_title','field_695530001b005'),
(402,7,'page_content_advantages-section_items_3_g_text','Абсолютна безпека ваших даних та інформації.'),
(403,7,'_page_content_advantages-section_items_3_g_text','field_695530001b006'),
(404,7,'page_content_advantages-section_items_3_g',''),
(405,7,'_page_content_advantages-section_items_3_g','field_69bd477a37d4a'),
(406,166,'_wp_attached_file','2026/03/advantage_1.svg'),
(407,166,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:841;}'),
(408,167,'_wp_attached_file','2026/03/advantage_2.svg'),
(409,167,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:773;}'),
(410,168,'_wp_attached_file','2026/03/advantage_3.svg'),
(411,168,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:1172;}'),
(412,169,'_wp_attached_file','2026/03/advantage_4.svg'),
(413,169,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:718;}'),
(414,170,'_wp_attached_file','2026/03/visual.webp'),
(415,170,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:1408;s:6:\"height\";i:768;s:4:\"file\";s:19:\"2026/03/visual.webp\";s:8:\"filesize\";i:163140;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:19:\"visual-300x164.webp\";s:5:\"width\";i:300;s:6:\"height\";i:164;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:6286;}s:5:\"large\";a:5:{s:4:\"file\";s:20:\"visual-1024x559.webp\";s:5:\"width\";i:1024;s:6:\"height\";i:559;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:29086;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:19:\"visual-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:3978;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:19:\"visual-768x419.webp\";s:5:\"width\";i:768;s:6:\"height\";i:419;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:20416;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(416,7,'_thumbnail_id','170'),
(417,147,'_thumbnail_id','170'),
(418,153,'_thumbnail_id','170'),
(419,171,'_edit_lock','1774271798:1'),
(420,171,'_edit_last','1'),
(421,217,'_wp_attached_file','2026/03/partner.webp'),
(422,217,'_wp_attachment_metadata','a:6:{s:5:\"width\";i:896;s:6:\"height\";i:1280;s:4:\"file\";s:20:\"2026/03/partner.webp\";s:8:\"filesize\";i:234800;s:5:\"sizes\";a:4:{s:6:\"medium\";a:5:{s:4:\"file\";s:20:\"partner-210x300.webp\";s:5:\"width\";i:210;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:6420;}s:5:\"large\";a:5:{s:4:\"file\";s:21:\"partner-717x1024.webp\";s:5:\"width\";i:717;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:39180;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"partner-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:3370;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:21:\"partner-768x1097.webp\";s:5:\"width\";i:768;s:6:\"height\";i:1097;s:9:\"mime-type\";s:10:\"image/webp\";s:8:\"filesize\";i:42032;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(423,10,'_edit_last','1'),
(424,10,'page_content_intro-section_title','Про нас'),
(425,10,'_page_content_intro-section_title','field_69c120a699017'),
(426,10,'page_content_intro-section_supertitle','Історія бюро, наша експертиза та ключові цінності.'),
(427,10,'_page_content_intro-section_supertitle','field_69c120a69cabc'),
(428,10,'page_content_intro-section',''),
(429,10,'_page_content_intro-section','field_69c120a67f1d1'),
(430,10,'page_content_founder-section_photo','217'),
(431,10,'_page_content_founder-section_photo','field_69c12216f16f3'),
(432,10,'page_content_founder-section_g_name','Ігор Мельник'),
(433,10,'_page_content_founder-section_g_name','field_69c12252f16f5'),
(434,10,'page_content_founder-section_g_position','Керуючий Партнер / Засновник'),
(435,10,'_page_content_founder-section_g_position','field_69c12264f16f6'),
(436,10,'page_content_founder-section_g_content','Адвокат з понад <strong>15-річним досвідом</strong> у сфері корпоративного права, вирішення складних комерційних спорів та захисту бізнесу. Засновник адвокатського бюро \"<strong>Ігор Мельник та Партнери</strong>\".\r\n\r\nЗакінчив юридичний факультет ЛНУ ім. Івана Франка. Працював на керівних посадах у провідних юридичних компаніях України, перш ніж заснувати власне бюро, яке сьогодні об\'єднує команду висококваліфікованих експертів.\r\n\r\n\"<strong>Наша головна мета</strong> - не просто надавати юридичні послуги, а бути стратегічним партнером для вашого бізнесу, забезпечуючи його стабільний розвиток та безпеку.\"'),
(437,10,'_page_content_founder-section_g_content','field_69c12274f16f7'),
(438,10,'page_content_founder-section_g',''),
(439,10,'_page_content_founder-section_g','field_69c12242f16f4'),
(440,10,'page_content_founder-section',''),
(441,10,'_page_content_founder-section','field_69c121f6f16f0'),
(442,10,'page_content_mission-section_title','Місія та цінності'),
(443,10,'_page_content_mission-section_title','field_69c1237e0c524'),
(444,10,'page_content_mission-section_items','2'),
(445,10,'_page_content_mission-section_items','field_69c123990c526'),
(446,10,'page_content_mission-section',''),
(447,10,'_page_content_mission-section','field_69c1237e0c523'),
(448,10,'page_content_principles-section_title','Наші принципи роботи'),
(449,10,'_page_content_principles-section_title','field_69c124dde1289'),
(450,10,'page_content_principles-section_items','2'),
(451,10,'_page_content_principles-section_items','field_69c124dde128a'),
(452,10,'page_content_principles-section',''),
(453,10,'_page_content_principles-section','field_69c124dde1288'),
(454,10,'page_content',''),
(455,10,'_page_content','field_69c120a677c79'),
(456,10,'page_content_mission-section_items_0_title','Місія'),
(457,10,'_page_content_mission-section_items_0_title','field_69c123ac0c527'),
(458,10,'page_content_mission-section_items_0_content','Надавати бездоганну юридичну підтримку бізнесу, захищаючи інтереси клієнтів за допомогою інноваційних правових рішень та глибокої експертизи.\r\n\r\nМи прагнемо формувати високі стандарти надання юридичних послуг в Україні.'),
(459,10,'_page_content_mission-section_items_0_content','field_69c123c60c528'),
(460,10,'page_content_mission-section_items_1_title','Цінності'),
(461,10,'_page_content_mission-section_items_1_title','field_69c123ac0c527'),
(462,10,'page_content_mission-section_items_1_content','<strong>Професіоналізм</strong>. Постійне вдосконалення знань та навичок нашої команди.\r\n\r\n<strong>Чесність</strong>. Відкриті та прозорі відносини з клієнтами на кожному етапі співпраці.\r\n\r\n<strong>Результативність</strong>. Орієнтація на практичний результат, а не просто процес.'),
(463,10,'_page_content_mission-section_items_1_content','field_69c123c60c528'),
(464,10,'page_content_principles-section_items_0_image','170'),
(465,10,'_page_content_principles-section_items_0_image','field_69c12502e128d'),
(466,10,'page_content_principles-section_items_0_g_title','Глибоке занурення в задачу'),
(467,10,'_page_content_principles-section_items_0_g_title','field_69c12525e128f'),
(468,10,'page_content_principles-section_items_0_g_content','На старті проєкту ми детально аналізуємо бізнес-модель, ризики та контекст спору, щоб запропонувати стратегію, яка працює в реальних умовах.\r\n'),
(469,10,'_page_content_principles-section_items_0_g_content','field_69c12541e1290'),
(470,10,'page_content_principles-section_items_0_g',''),
(471,10,'_page_content_principles-section_items_0_g','field_69c1251ee128e'),
(472,10,'page_content_principles-section_items_1_image','170'),
(473,10,'_page_content_principles-section_items_1_image','field_69c12502e128d'),
(474,10,'page_content_principles-section_items_1_g_title','Прозора комунікація'),
(475,10,'_page_content_principles-section_items_1_g_title','field_69c12525e128f'),
(476,10,'page_content_principles-section_items_1_g_content','Кожен етап супроводу супроводжується зрозумілими поясненнями, прогнозами щодо строків і регулярними оновленнями, щоб ви завжди контролювали процес.'),
(477,10,'_page_content_principles-section_items_1_g_content','field_69c12541e1290'),
(478,10,'page_content_principles-section_items_1_g',''),
(479,10,'_page_content_principles-section_items_1_g','field_69c1251ee128e'),
(480,10,'page_content_intro-section_subtitle','Історія бюро, наша експертиза та ключові цінності.'),
(481,10,'_page_content_intro-section_subtitle','field_69c120a69cabc'),
(482,218,'_edit_last','1'),
(483,218,'_edit_lock','1774271430:1'),
(484,10,'page-description','Історія бюро, наша експертиза та ключові цінності.'),
(485,10,'_page-description','field_69c138924d7a7'),
(486,15,'_edit_lock','1774277836:1'),
(487,12,'page-description','Ми пропонуємо широкий спектр послуг, щоб допомогти вам досягти ваших цілей.'),
(488,12,'_page-description','field_69c138924d7a7'),
(489,13,'_edit_last','1'),
(490,13,'page-description','Аналітика законодавства, успішні кейси та поради для бізнесу.'),
(491,13,'_page-description','field_69c138924d7a7'),
(492,14,'_edit_lock','1774276114:1'),
(493,14,'_edit_last','1'),
(494,14,'page-description','Безкоштовні шаблони базових юридичних документів для вашого бізнесу'),
(495,14,'_page-description','field_69c138924d7a7'),
(496,220,'_edit_lock','1774277835:1'),
(497,220,'_edit_last','1'),
(498,255,'_edit_last','1'),
(499,255,'_edit_lock','1774274858:1'),
(500,256,'_edit_last','1'),
(501,256,'_edit_lock','1774274884:1'),
(502,255,'document-data_file','262'),
(503,255,'_document-data_file','field_69c142abe21eb'),
(504,255,'document-data_g_tag','Договори'),
(505,255,'_document-data_g_tag','field_69c142d2e21ec'),
(506,255,'document-data_g_description','Конфіденційність'),
(507,255,'_document-data_g_description','field_69c142f7e21ee'),
(508,255,'document-data_g',''),
(509,255,'_document-data_g','field_69c142e7e21ed'),
(510,255,'document-data',''),
(511,255,'_document-data','field_69c1427ce21ea'),
(512,262,'_wp_attached_file','2026/03/shablon_dogovoru_pro_nadannya_poslug.pdf'),
(513,262,'_wp_attachment_metadata','a:1:{s:8:\"filesize\";i:34839;}'),
(514,14,'page_content_info','<strong>Зверніть увагу</strong>\r\n\r\nЦі шаблони є типовими зразками. Для врахування специфіки вашої діяльності та максимального захисту ваших інтересів, рекомендуємо звернутись за індивідуальною розробкою договору до наших спеціалістів.'),
(515,14,'_page_content_info','field_69c13c5c35346'),
(516,14,'page_content',''),
(517,14,'_page_content','field_69c13c5c268c7'),
(524,15,'_edit_last','1'),
(525,15,'page-description','Готові обговорити вашу справу. \r\nЗв\'яжіться з нами зручним для вас способом'),
(526,15,'_page-description','field_69c138924d7a7');
/*!40000 ALTER TABLE `bb_postmeta` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_posts`
--

DROP TABLE IF EXISTS `bb_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `type_status_author` (`post_type`,`post_status`,`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_posts`
--

LOCK TABLES `bb_posts` WRITE;
/*!40000 ALTER TABLE `bb_posts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_posts` VALUES
(7,1,'2026-03-16 20:06:37','2026-03-16 18:06:37','','Головна','','publish','closed','closed','','golovna','','','2026-03-23 12:56:53','2026-03-23 10:56:53','',0,'http://imp.loc/?page_id=7',1,'page','',0),
(8,1,'2026-03-16 20:07:10','2026-03-16 18:07:10','{\n    \"show_on_front\": {\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-03-16 18:07:10\"\n    },\n    \"page_on_front\": {\n        \"value\": \"7\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-03-16 18:07:10\"\n    }\n}','','','trash','closed','closed','','2c84b63e-fb20-4f26-84d1-8f9e2c319349','','','2026-03-16 20:07:10','2026-03-16 18:07:10','',0,'http://imp.loc/2c84b63e-fb20-4f26-84d1-8f9e2c319349/',0,'customize_changeset','',0),
(10,1,'2026-03-16 21:01:12','2026-03-16 19:01:12','','Про Нас','','publish','closed','closed','','about-us','','','2026-03-23 15:04:40','2026-03-23 13:04:40','',0,'http://imp.loc/?page_id=10',2,'page','',0),
(12,1,'2026-03-16 21:05:00','2026-03-16 19:05:00','','Наші Послуги','','publish','closed','closed','','services','','','2026-03-23 15:07:51','2026-03-23 13:07:51','',0,'http://imp.loc/?page_id=12',5,'page','',0),
(13,1,'2026-03-16 21:05:20','2026-03-16 19:05:20','','Блог','','publish','closed','closed','','blog','','','2026-03-23 15:10:47','2026-03-23 13:10:47','',0,'http://imp.loc/?page_id=13',6,'page','',0),
(14,1,'2026-03-16 21:05:40','2026-03-16 19:05:40','','Документи','','publish','closed','closed','','documents','','','2026-03-23 16:16:16','2026-03-23 14:16:16','',0,'http://imp.loc/?page_id=14',4,'page','',0),
(15,1,'2026-03-16 21:06:00','2026-03-16 19:06:00','','Контакти','','publish','closed','closed','','contacts','','','2026-03-23 16:41:58','2026-03-23 14:41:58','',0,'http://imp.loc/?page_id=15',3,'page','',0),
(17,1,'2026-03-18 19:20:32','2026-03-18 17:14:40',' ','','','publish','closed','closed','','17','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=17',6,'nav_menu_item','',0),
(18,1,'2026-03-18 19:20:32','2026-03-18 17:14:40',' ','','','publish','closed','closed','','18','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=18',5,'nav_menu_item','',0),
(19,1,'2026-03-18 19:20:32','2026-03-18 17:14:40',' ','','','publish','closed','closed','','19','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=19',4,'nav_menu_item','',0),
(20,1,'2026-03-18 19:20:32','2026-03-18 17:14:40',' ','','','publish','closed','closed','','20','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=20',3,'nav_menu_item','',0),
(21,1,'2026-03-18 19:20:32','2026-03-18 17:14:40',' ','','','publish','closed','closed','','21','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=21',2,'nav_menu_item','',0),
(22,1,'2026-03-18 19:20:32','2026-03-18 17:14:40','','Головна','','publish','closed','closed','','golovna','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=22',1,'nav_menu_item','',0),
(23,1,'2026-03-18 19:20:32','2026-03-18 17:15:16','','Замовити консультацію','','publish','closed','closed','','zamovyty-konsultacziyu','','','2026-03-18 19:20:32','2026-03-18 17:20:32','',0,'http://imp.loc/?p=23',7,'nav_menu_item','',0),
(24,1,'2026-03-18 19:29:50','0000-00-00 00:00:00','','Авточернетка','','auto-draft','closed','closed','','','','','2026-03-18 19:29:50','0000-00-00 00:00:00','',0,'http://imp.loc/?post_type=services&p=24',0,'services','',0),
(25,1,'2026-03-18 19:30:49','2026-03-18 17:30:49','','Корпоративне право','Комплексний юридичний супровід та захист інтересів у даній сфері.','publish','closed','closed','','korporatyvne-pravo','','','2026-03-22 16:50:04','2026-03-22 14:50:04','',0,'http://imp.loc/?post_type=services&#038;p=25',1,'services','',0),
(64,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"front-page.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Page | Home','page-home','publish','closed','closed','','group_695520e55fec9','','','2026-03-23 12:45:08','2026-03-23 10:45:08','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=64',0,'acf-field-group','',0),
(65,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','page_content','publish','closed','closed','','field_695520e5dcba2','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',64,'http://imp.loc/?post_type=acf-field&p=65',0,'acf-field','',0),
(66,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Головна','','publish','closed','closed','','field_6955228f1e73a','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=66',0,'acf-field','',0),
(67,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','intro-section','publish','closed','closed','','field_695522a01e73b','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=67',1,'acf-field','',0),
(68,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:3:\"100\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:1;s:4:\"rows\";i:2;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','Назва','title','publish','closed','closed','','field_695525281e73d','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',67,'http://imp.loc/?post_type=acf-field&p=68',0,'acf-field','',0),
(69,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:3:\"100\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Опис','supertitle','publish','closed','closed','','field_695522ae1e73c','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',67,'http://imp.loc/?post_type=acf-field&p=69',1,'acf-field','',0),
(70,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:17:\"allow_in_bindings\";i:0;}','Кнопка консультації','button','publish','closed','closed','','field_695525bfd2c0d','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',67,'http://imp.loc/?post_type=acf-field&p=70',2,'acf-field','',0),
(71,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"50\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:17:\"allow_in_bindings\";i:0;}','Додаткова кнопка','button_2','publish','closed','closed','','field_69bd4684f70b7','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',67,'http://imp.loc/?post_type=acf-field&p=71',3,'acf-field','',0),
(72,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Практики','','publish','closed','closed','','field_695530001a000','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=72',2,'acf-field','',0),
(73,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','practices-section','publish','closed','closed','','field_695530001a001','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=73',3,'acf-field','',0),
(74,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_695530001a002','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',73,'http://imp.loc/?post_type=acf-field&p=74',0,'acf-field','',0),
(75,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:12:\"relationship\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:8:\"services\";}s:11:\"post_status\";a:1:{i:0;s:7:\"publish\";}s:8:\"taxonomy\";s:0:\"\";s:7:\"filters\";s:0:\"\";s:13:\"return_format\";s:6:\"object\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:17:\"allow_in_bindings\";i:1;s:8:\"elements\";s:0:\"\";s:13:\"bidirectional\";i:0;s:20:\"bidirectional_target\";a:0:{}}','Перелік','items','publish','closed','closed','','field_695530001a003','','','2026-03-20 15:21:16','2026-03-20 13:21:16','',73,'http://imp.loc/?post_type=acf-field&#038;p=75',1,'acf-field','',0),
(76,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:17:\"allow_in_bindings\";i:0;}','Кнопка','button','publish','closed','closed','','field_695530001a008','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',73,'http://imp.loc/?post_type=acf-field&p=76',2,'acf-field','',0),
(77,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Переваги','','publish','closed','closed','','field_695530001b000','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=77',4,'acf-field','',0),
(78,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','advantages-section','publish','closed','closed','','field_695530001b001','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=78',5,'acf-field','',0),
(79,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_695530001b002','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',78,'http://imp.loc/?post_type=acf-field&p=79',0,'acf-field','',0),
(80,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:12:\"button_label\";s:27:\"Додати елемент\";s:3:\"min\";i:0;s:3:\"max\";i:0;s:13:\"rows_per_page\";i:20;s:9:\"collapsed\";s:0:\"\";}','Перелік','items','publish','closed','closed','','field_695530001b003','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',78,'http://imp.loc/?post_type=acf-field&p=80',1,'acf-field','',0),
(81,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"20\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:12:\"preview_size\";s:9:\"thumbnail\";}','Іконка','icon','publish','closed','closed','','field_695530001b004','','','2026-03-23 12:45:08','2026-03-23 10:45:08','',80,'http://imp.loc/?post_type=acf-field&#038;p=81',0,'acf-field','',0),
(82,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"80\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:15:\"parent_repeater\";s:19:\"field_695530001b003\";s:10:\"sub_fields\";a:0:{}}','','g','publish','closed','closed','','field_69bd477a37d4a','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',80,'http://imp.loc/?post_type=acf-field&p=82',1,'acf-field','',0),
(83,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:3:\"100\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_695530001b005','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',82,'http://imp.loc/?post_type=acf-field&p=83',0,'acf-field','',0),
(84,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:3:\"100\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:2;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','Опис','text','publish','closed','closed','','field_695530001b006','','','2026-03-20 16:28:46','2026-03-20 14:28:46','',82,'http://imp.loc/?post_type=acf-field&#038;p=84',1,'acf-field','',0),
(85,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Останні новини','','publish','closed','closed','','field_695530001c000','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=85',6,'acf-field','',0),
(86,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','latest-news-section','publish','closed','closed','','field_695530001c001','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',65,'http://imp.loc/?post_type=acf-field&p=86',7,'acf-field','',0),
(87,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_695530001c002','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',86,'http://imp.loc/?post_type=acf-field&p=87',0,'acf-field','',0),
(88,1,'2026-03-20 15:19:47','2026-03-20 13:19:47','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:17:\"allow_in_bindings\";i:0;}','Кнопка','button','publish','closed','closed','','field_695530001c003','','','2026-03-20 15:19:47','2026-03-20 13:19:47','',86,'http://imp.loc/?post_type=acf-field&p=88',1,'acf-field','',0),
(89,1,'2026-03-21 19:03:08','2026-03-21 17:03:08','<p class=\"form-title font-28\">Надіслати запит</p>\r\n<label>\r\n  <span class=\"placeholder\">Ваше ім\'я</span>\r\n  [text* your_name minlength:3 maxlength:40 placeholder \"Ваше ім\'я\" ]\r\n</label>\r\n<label>\r\n  <span class=\"placeholder\">E-mail</span>\r\n  [email your_email maxlength:40 placeholder \"Ваш E-mail\"]\r\n</label>\r\n<label>\r\n  <span class=\"placeholder\">Короткий опис</span>\r\n  [textarea user_message 10x3 placeholder \"Опишіть суть вашого питання...\"]\r\n</label>\r\n<button class=\"cta gold\">Надіслати</button>\n1\n[_site_title] від [your_name]\n[_site_title] <wordpress@imp.loc>\n[_site_admin_email]\nВід: [your_name]\r\nEmail: [your_email]\r\nПовідомлення: \r\n[user_message]\r\n\r\n\r\n\r\nЦе сповіщення про те, що на вашому вебсайті було надіслано контактну форму ([_site_title] [_site_url]).\nReply-To: [_site_admin_email]\n\n1\n1\n\n[_site_title] \"[your-subject]\"\n[_site_title] <wordpress@imp.loc>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.\nReply-To: [_site_admin_email]\n\n1\n1\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.\nPlease enter a date in YYYY-MM-DD format.\nThis field has a too early date.\nThis field has a too late date.\nPlease enter a number.\nThis field has a too small number.\nThis field has a too large number.\nThe answer to the quiz is incorrect.\nPlease enter an email address.\nPlease enter a URL.\nPlease enter a telephone number.','Форма зв\'язку','','publish','closed','closed','','contact-form-1','','','2026-03-25 11:33:34','2026-03-25 09:33:34','',0,'http://imp.loc/?post_type=wpcf7_contact_form&#038;p=89',0,'wpcf7_contact_form','',0),
(90,1,'2026-03-21 20:46:48','2026-03-21 18:46:48','','Навігація','','publish','closed','closed','','navigacziya','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=90',1,'nav_menu_item','',0),
(91,1,'2026-03-21 20:46:48','2026-03-21 18:46:48',' ','','','publish','closed','closed','','91','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=91',6,'nav_menu_item','',0),
(92,1,'2026-03-21 20:46:48','2026-03-21 18:46:48',' ','','','publish','closed','closed','','92','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=92',5,'nav_menu_item','',0),
(93,1,'2026-03-21 20:46:48','2026-03-21 18:46:48',' ','','','publish','closed','closed','','93','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=93',4,'nav_menu_item','',0),
(94,1,'2026-03-21 20:46:48','2026-03-21 18:46:48',' ','','','publish','closed','closed','','94','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=94',3,'nav_menu_item','',0),
(95,1,'2026-03-21 20:46:48','2026-03-21 18:46:48',' ','','','publish','closed','closed','','95','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=95',2,'nav_menu_item','',0),
(96,1,'2026-03-21 20:46:48','2026-03-21 18:46:48','','Послуги','','publish','closed','closed','','poslugy','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=96',7,'nav_menu_item','',0),
(97,1,'2026-03-21 20:46:48','2026-03-21 18:46:48',' ','','','publish','closed','closed','','97','','','2026-03-21 20:46:48','2026-03-21 18:46:48','',0,'http://imp.loc/?p=97',8,'nav_menu_item','',0),
(119,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:17:\"contacts-settings\";}}}s:8:\"position\";s:15:\"acf_after_title\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Загальні дані','zagalni-dani','publish','closed','closed','','group_63411aed34d72','','','2026-03-23 16:39:42','2026-03-23 14:39:42','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=119',0,'acf-field-group','',0),
(120,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:12:\"preview_size\";s:9:\"thumbnail\";}','Лого','logo','publish','closed','closed','','field_69beef4b72758','','','2026-03-21 21:50:34','2026-03-21 19:50:34','',140,'http://imp.loc/?post_type=acf-field&#038;p=120',0,'acf-field','',0),
(121,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:2;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','Адреса','address','publish','closed','closed','','field_contacts_address','','','2026-03-21 21:47:59','2026-03-21 19:47:59','',140,'http://imp.loc/?post_type=acf-field&#038;p=121',3,'acf-field','',0),
(122,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:13:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"table\";s:10:\"pagination\";i:0;s:3:\"min\";i:0;s:3:\"max\";i:0;s:9:\"collapsed\";s:0:\"\";s:12:\"button_label\";s:23:\"Додати номер\";s:13:\"rows_per_page\";i:20;}','Телефони','phones','publish','closed','closed','','field_contacts_phones','','','2026-03-21 21:47:59','2026-03-21 19:47:59','',140,'http://imp.loc/?post_type=acf-field&#038;p=122',4,'acf-field','',0),
(123,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;}','Номер телефону','phone_number','publish','closed','closed','','field_contacts_phone_number','','','2026-03-21 21:26:38','2026-03-21 19:26:38','',122,'http://imp.loc/?post_type=acf-field&p=123',0,'acf-field','',0),
(124,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:13:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"table\";s:10:\"pagination\";i:0;s:3:\"min\";i:0;s:3:\"max\";i:0;s:9:\"collapsed\";s:0:\"\";s:12:\"button_label\";s:18:\"Додати email\";s:13:\"rows_per_page\";i:20;}','Email','emails','publish','closed','closed','','field_contacts_emails','','','2026-03-21 21:47:59','2026-03-21 19:47:59','',140,'http://imp.loc/?post_type=acf-field&#038;p=124',5,'acf-field','',0),
(125,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:11:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"email\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;}','Email','email_address','publish','closed','closed','','field_contacts_email_address','','','2026-03-21 21:26:38','2026-03-21 19:26:38','',124,'http://imp.loc/?post_type=acf-field&p=125',0,'acf-field','',0),
(126,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:2;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}','Уривок','text','publish','closed','closed','','field_683465128791d','','','2026-03-21 21:47:59','2026-03-21 19:47:59','',140,'http://imp.loc/?post_type=acf-field&#038;p=126',1,'acf-field','',0),
(127,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:13:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"table\";s:10:\"pagination\";i:0;s:3:\"min\";i:0;s:3:\"max\";i:0;s:9:\"collapsed\";s:0:\"\";s:12:\"button_label\";s:7:\"Add Row\";s:13:\"rows_per_page\";i:20;}','Соціальні мережі','socials','publish','closed','closed','','field_683465188791e_field_6834652cf6284','','','2026-03-21 21:47:59','2026-03-21 19:47:59','',140,'http://imp.loc/?post_type=acf-field&#038;p=127',2,'acf-field','',0),
(128,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"30\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:3:\"svg\";s:17:\"allow_in_bindings\";i:0;s:12:\"preview_size\";s:9:\"thumbnail\";}','Іконка','custom_icon','publish','closed','closed','','field_6834663af6286','','','2026-03-21 22:15:55','2026-03-21 20:15:55','',127,'http://imp.loc/?post_type=acf-field&#038;p=128',0,'acf-field','',0),
(129,1,'2026-03-21 21:26:38','2026-03-21 19:26:38','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"72\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";}','Лінк','url','publish','closed','closed','','field_68346a12f6287','','','2026-03-21 22:15:55','2026-03-21 20:15:55','',127,'http://imp.loc/?post_type=acf-field&#038;p=129',1,'acf-field','',0),
(131,1,'2026-03-21 21:34:45','2026-03-21 19:34:45','','favicon','','inherit','closed','closed','','favicon','','','2026-03-21 21:34:45','2026-03-21 19:34:45','',0,'http://imp.loc/wp-content/uploads/2026/03/favicon.png',0,'attachment','image/png',0),
(132,1,'2026-03-21 21:34:47','2026-03-21 19:34:47','http://imp.loc/wp-content/uploads/2026/03/cropped-favicon.png','cropped-favicon.png','','inherit','closed','closed','','cropped-favicon-png','','','2026-03-21 21:34:47','2026-03-21 19:34:47','',131,'http://imp.loc/wp-content/uploads/2026/03/cropped-favicon.png',0,'attachment','image/png',0),
(133,1,'2026-03-21 21:34:57','2026-03-21 19:34:57','http://imp.loc/wp-content/uploads/2026/03/cropped-favicon-1.png','cropped-favicon-1.png','','inherit','closed','closed','','cropped-favicon-1-png','','','2026-03-21 21:34:57','2026-03-21 19:34:57','',131,'http://imp.loc/wp-content/uploads/2026/03/cropped-favicon-1.png',0,'attachment','image/png',0),
(134,1,'2026-03-21 21:36:35','2026-03-21 19:36:35','{\n    \"site_icon\": {\n        \"value\": 133,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-03-21 19:35:13\"\n    },\n    \"bamboo::custom_logo\": {\n        \"value\": 135,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-03-21 19:36:21\"\n    }\n}','','','trash','closed','closed','','ff01cd43-54fa-4f1a-b519-2068232b6cc2','','','2026-03-21 21:36:35','2026-03-21 19:36:35','',0,'http://imp.loc/?p=134',0,'customize_changeset','',0),
(136,1,'2026-03-21 21:36:55','2026-03-21 19:36:55','{\n    \"page_for_posts\": {\n        \"value\": \"13\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-03-21 19:36:55\"\n    }\n}','','','trash','closed','closed','','4c96bc29-553e-44c9-ad39-2e9ae2f443b6','','','2026-03-21 21:36:55','2026-03-21 19:36:55','',0,'http://imp.loc/4c96bc29-553e-44c9-ad39-2e9ae2f443b6/',0,'customize_changeset','',0),
(138,1,'2026-03-21 21:40:10','2026-03-21 19:40:10','','logo-colored','','inherit','closed','closed','','logo-colored','','','2026-03-21 21:40:10','2026-03-21 19:40:10','',0,'http://imp.loc/wp-content/uploads/2026/03/logo-colored.svg',0,'attachment','image/svg+xml',0),
(139,1,'2026-03-21 21:40:46','2026-03-21 19:40:46','{\n    \"bamboo::custom_logo\": {\n        \"value\": 138,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2026-03-21 19:40:46\"\n    }\n}','','','trash','closed','closed','','0ab06036-ccfd-44fc-be44-8be3d5788e3c','','','2026-03-21 21:40:46','2026-03-21 19:40:46','',0,'http://imp.loc/0ab06036-ccfd-44fc-be44-8be3d5788e3c/',0,'customize_changeset','',0),
(140,1,'2026-03-21 21:47:59','2026-03-21 19:47:59','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','footer','publish','closed','closed','','field_69bef5afc4136','','','2026-03-23 16:36:45','2026-03-23 14:36:45','',119,'http://imp.loc/?post_type=acf-field&#038;p=140',1,'acf-field','',0),
(141,1,'2026-03-21 21:48:50','2026-03-21 19:48:50','','','','inherit','closed','closed','','logo-long','','','2026-03-21 21:52:20','2026-03-21 19:52:20','',0,'http://imp.loc/wp-content/uploads/2026/03/logo-long.svg',0,'attachment','image/svg+xml',0),
(142,1,'2026-03-21 22:14:16','2026-03-21 20:14:16','','whatsapp','','inherit','closed','closed','','whatsapp','','','2026-03-21 22:14:16','2026-03-21 20:14:16','',0,'http://imp.loc/wp-content/uploads/2026/03/whatsapp.svg',0,'attachment','image/svg+xml',0),
(143,1,'2026-03-21 22:14:26','2026-03-21 20:14:26','','facebook','','inherit','closed','closed','','facebook','','','2026-03-21 22:14:26','2026-03-21 20:14:26','',0,'http://imp.loc/wp-content/uploads/2026/03/facebook.svg',0,'attachment','image/svg+xml',0),
(144,1,'2026-03-21 22:14:26','2026-03-21 20:14:26','','instagram','','inherit','closed','closed','','instagram','','','2026-03-21 22:14:26','2026-03-21 20:14:26','',0,'http://imp.loc/wp-content/uploads/2026/03/instagram.svg',0,'attachment','image/svg+xml',0),
(145,1,'2026-03-21 22:14:26','2026-03-21 20:14:26','','telegram','','inherit','closed','closed','','telegram','','','2026-03-21 22:14:26','2026-03-21 20:14:26','',0,'http://imp.loc/wp-content/uploads/2026/03/telegram.svg',0,'attachment','image/svg+xml',0),
(147,1,'2026-03-22 11:38:24','2026-03-22 09:38:24','<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">У Верховній Раді України зареєстровано законопроєкт <strong><a href=\"https://itd.rada.gov.ua/billinfo/Bills/Card/69594\">№15031</a></strong>, який має на меті вивести ринок оренди нерухомості з «тіні». Документ передбачає суттєве послаблення податкового тиску на орендодавців-фізичних осіб та запровадження тимчасових пільг на період дії воєнного стану.</h2>\n<!-- /wp:heading -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\"><strong>Ключові нововведення законопроєкту</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Проєкт закону пропонує внести зміни до Податкового кодексу України за наступними напрямами:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class=\"wp-block-list\"><!-- wp:list-item -->\n<li><strong>Зниження ставки ПДФО:</strong> пропонується встановити ставку на рівні <strong>5%</strong> замість нинішніх 18% для доходів, отриманих від надання житла в оренду.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Податкові канікули:</strong> передбачено період, коли доходи від оренди житла взагалі не включатимуться до загального оподатковуваного доходу. Пільга діятиме з <strong>1 квітня 2026 року</strong> до 31 грудня року, у якому буде скасовано воєнний стан.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Спрощена звітність:</strong> орендодавці зможуть самостійно нараховувати та сплачувати податок щокварталу (протягом 40 календарних днів після завершення звітного кварталу).</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\"><strong>Чому ринок потребує змін?</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>На сьогодні сумарне податкове навантаження на офіційну оренду (18% ПДФО та 5% військового збору) змушує власників уникати укладання офіційних договорів.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><strong>Наслідки поточної ситуації:</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list {\"ordered\":true,\"start\":1} -->\n<ol start=\"1\" class=\"wp-block-list\"><!-- wp:list-item -->\n<li><strong>Бюджетні втрати:</strong> значна частина доходів не декларується, що призводить до недоотримання коштів державою.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li><strong>Незахищеність сторін:</strong> орендарі часто позбавлені правових гарантій, стикаючись із раптовим підвищенням плати або примусовим виселенням без повернення депозиту.</li>\n<!-- /wp:list-item --></ol>\n<!-- /wp:list -->\n\n<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\"><strong>Очікувані результати</strong></h3>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Автори ініціативи переконані, що лібералізація оподаткування стимулюватиме орендодавців легалізувати свою діяльність. Це дозволить:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul class=\"wp-block-list\"><!-- wp:list-item -->\n<li>Сформувати прозорий та цивілізований ринок нерухомості.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Підвищити рівень правового захисту як власників житла, так і наймачів.</li>\n<!-- /wp:list-item -->\n\n<!-- wp:list-item -->\n<li>Збільшити надходження до бюджету у довгостроковій перспективі за рахунок масового добровільного декларування.</li>\n<!-- /wp:list-item --></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>Реалізація законопроєкту не потребуватиме додаткових витрат із державного бюдже</p>\n<!-- /wp:paragraph -->','У Парламенті пропонують радикально знизити податки на оренду житла: деталі законопроєкту №15031','Практичний чекліст для бізнесу перед підписанням господарських договорів.','publish','closed','closed','','yak-zmenshyty-ryzyky-u-dogovorah-u-2026-roczi','','','2026-03-23 13:10:02','2026-03-23 11:10:02','',0,'http://imp.loc/?post_type=blog&#038;p=147',2,'blog','',0),
(148,1,'2026-03-22 11:40:16','2026-03-22 09:40:16','<!-- wp:navigation-submenu {\"className\":\" menu-item menu-item-type-custom menu-item-object-custom\",\"description\":\"\",\"id\":null,\"kind\":\"custom\",\"label\":\"Навігація\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"custom\",\"url\":\"#\"} --><!-- wp:navigation-link {\"className\":\" menu-item menu-item-type-post_type menu-item-object-page\",\"description\":\"\",\"id\":\"10\",\"kind\":\"post-type\",\"label\":\"Про Нас\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"page\",\"url\":\"http://imp.loc/about-us/\"} /--><!-- wp:navigation-link {\"className\":\" menu-item menu-item-type-post_type menu-item-object-page\",\"description\":\"\",\"id\":\"12\",\"kind\":\"post-type\",\"label\":\"Наші Послуги\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"page\",\"url\":\"http://imp.loc/services/\"} /--><!-- wp:navigation-link {\"className\":\" menu-item menu-item-type-post_type menu-item-object-page current_page_parent\",\"description\":\"\",\"id\":\"13\",\"kind\":\"post-type\",\"label\":\"Блог\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"page\",\"url\":\"http://imp.loc/blog/\"} /--><!-- wp:navigation-link {\"className\":\" menu-item menu-item-type-post_type menu-item-object-page\",\"description\":\"\",\"id\":\"14\",\"kind\":\"post-type\",\"label\":\"Документи\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"page\",\"url\":\"http://imp.loc/documents/\"} /--><!-- wp:navigation-link {\"className\":\" menu-item menu-item-type-post_type menu-item-object-page\",\"description\":\"\",\"id\":\"15\",\"kind\":\"post-type\",\"label\":\"Контакти\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"page\",\"url\":\"http://imp.loc/contacts/\"} /--><!-- /wp:navigation-submenu --><!-- wp:navigation-submenu {\"className\":\" menu-item menu-item-type-custom menu-item-object-custom\",\"description\":\"\",\"id\":null,\"kind\":\"custom\",\"label\":\"Послуги\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"custom\",\"url\":\"#\"} --><!-- wp:navigation-link {\"className\":\" menu-item menu-item-type-post_type menu-item-object-services\",\"description\":\"\",\"id\":\"25\",\"kind\":\"post-type\",\"label\":\"Корпоративне право\",\"opensInNewTab\":false,\"rel\":null,\"title\":\"\",\"type\":\"services\",\"url\":\"http://imp.loc/services/korporatyvne-pravo/\"} /--><!-- /wp:navigation-submenu -->','Footer menu','','publish','closed','closed','','footer-menu','','','2026-03-22 11:40:16','2026-03-22 09:40:16','',0,'http://imp.loc/footer-menu/',0,'wp_navigation','',0),
(152,1,'2026-03-22 12:37:06','0000-00-00 00:00:00','','Авточернетка','','auto-draft','closed','closed','','','','','2026-03-22 12:37:06','0000-00-00 00:00:00','',0,'http://imp.loc/?post_type=blog&p=152',0,'blog','',0),
(153,1,'2026-03-22 14:43:28','2026-03-22 12:43:28','','У Парламенті пропонують 22','','publish','closed','closed','','u-parlamenti-proponuyut-22','','','2026-03-23 13:10:10','2026-03-23 11:10:10','',0,'http://imp.loc/?post_type=blog&#038;p=153',1,'blog','',0),
(156,1,'2026-03-22 16:11:45','2026-03-22 14:11:45','','Господарське право','Комплексний юридичний супровід та захист інтересів у даній сфері.','publish','closed','closed','','gospodarske-pravo','','','2026-03-22 16:50:15','2026-03-22 14:50:15','',0,'http://imp.loc/?post_type=services&#038;p=156',2,'services','',0),
(157,1,'2026-03-22 16:24:00','2026-03-22 14:24:00','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:8:\"services\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Послуги','poslugy','publish','closed','closed','','group_69bffb5025fe8','','','2026-03-22 16:47:09','2026-03-22 14:47:09','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=157',0,'acf-field-group','',0),
(158,1,'2026-03-22 16:24:00','2026-03-22 14:24:00','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','single-service','publish','closed','closed','','field_69bffb5000a30','','','2026-03-22 16:31:11','2026-03-22 14:31:11','',157,'http://imp.loc/?post_type=acf-field&#038;p=158',0,'acf-field','',0),
(159,1,'2026-03-22 16:24:00','2026-03-22 14:24:00','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','','content','publish','closed','closed','','field_69bffb6300a31','','','2026-03-22 16:38:22','2026-03-22 14:38:22','',158,'http://imp.loc/?post_type=acf-field&#038;p=159',1,'acf-field','',0),
(160,1,'2026-03-22 16:38:22','2026-03-22 14:38:22','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:12:\"preview_size\";s:9:\"thumbnail\";}','Іконка','icon','publish','closed','closed','','field_69bffeb25599b','','','2026-03-22 16:47:09','2026-03-22 14:47:09','',158,'http://imp.loc/?post_type=acf-field&#038;p=160',0,'acf-field','',0),
(162,1,'2026-03-22 16:49:57','2026-03-22 14:49:57','','sercive-1','','inherit','closed','closed','','sercive-1','','','2026-03-22 16:49:57','2026-03-22 14:49:57','',25,'http://imp.loc/wp-content/uploads/2026/03/sercive-1.svg',0,'attachment','image/svg+xml',0),
(163,1,'2026-03-22 16:50:13','2026-03-22 14:50:13','','sercive-2','','inherit','closed','closed','','sercive-2','','','2026-03-22 16:50:13','2026-03-22 14:50:13','',156,'http://imp.loc/wp-content/uploads/2026/03/sercive-2.svg',0,'attachment','image/svg+xml',0),
(164,1,'2026-03-22 16:50:40','2026-03-22 14:50:40','','Судове представництво','Ефективне представництво в судах всіх інстанцій.','publish','closed','closed','','sudove-predstavnycztvo','','','2026-03-22 16:50:59','2026-03-22 14:50:59','',0,'http://imp.loc/?post_type=services&#038;p=164',3,'services','',0),
(165,1,'2026-03-22 16:50:37','2026-03-22 14:50:37','','sercive-3','','inherit','closed','closed','','sercive-3','','','2026-03-22 16:50:37','2026-03-22 14:50:37','',164,'http://imp.loc/wp-content/uploads/2026/03/sercive-3.svg',0,'attachment','image/svg+xml',0),
(166,1,'2026-03-23 12:48:32','2026-03-23 10:48:32','','advantage_1','','inherit','closed','closed','','advantage_1','','','2026-03-23 12:48:32','2026-03-23 10:48:32','',7,'http://imp.loc/wp-content/uploads/2026/03/advantage_1.svg',0,'attachment','image/svg+xml',0),
(167,1,'2026-03-23 12:48:32','2026-03-23 10:48:32','','advantage_2','','inherit','closed','closed','','advantage_2','','','2026-03-23 12:48:32','2026-03-23 10:48:32','',7,'http://imp.loc/wp-content/uploads/2026/03/advantage_2.svg',0,'attachment','image/svg+xml',0),
(168,1,'2026-03-23 12:48:32','2026-03-23 10:48:32','','advantage_3','','inherit','closed','closed','','advantage_3','','','2026-03-23 12:48:32','2026-03-23 10:48:32','',7,'http://imp.loc/wp-content/uploads/2026/03/advantage_3.svg',0,'attachment','image/svg+xml',0),
(169,1,'2026-03-23 12:48:32','2026-03-23 10:48:32','','advantage_4','','inherit','closed','closed','','advantage_4','','','2026-03-23 12:48:32','2026-03-23 10:48:32','',7,'http://imp.loc/wp-content/uploads/2026/03/advantage_4.svg',0,'attachment','image/svg+xml',0),
(170,1,'2026-03-23 12:56:27','2026-03-23 10:56:27','','visual','','inherit','closed','closed','','visual','','','2026-03-23 12:56:27','2026-03-23 10:56:27','',7,'http://imp.loc/wp-content/uploads/2026/03/visual.webp',0,'attachment','image/webp',0),
(171,1,'2026-03-23 13:14:46','2026-03-23 11:14:46','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"page-about.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Page | About','page-about','publish','closed','closed','','group_69c120a675a17','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=171',0,'acf-field-group','',0),
(172,1,'2026-03-23 13:14:46','2026-03-23 11:14:46','a:7:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";}','','page_content','publish','closed','closed','','field_69c120a677c79','','','2026-03-23 13:14:46','2026-03-23 11:14:46','',171,'http://imp.loc/?post_type=acf-field&#038;p=172',0,'acf-field','',0),
(196,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";b:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Засновник','_копіювати','publish','closed','closed','','field_69c121e2f16ef','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',172,'http://imp.loc/?post_type=acf-field&#038;p=196',0,'acf-field','',0),
(197,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','founder-section','publish','closed','closed','','field_69c121f6f16f0','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',172,'http://imp.loc/?post_type=acf-field&#038;p=197',1,'acf-field','',0),
(198,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"20\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:12:\"preview_size\";s:6:\"medium\";}','Фото','photo','publish','closed','closed','','field_69c12216f16f3','','','2026-03-23 13:22:53','2026-03-23 11:22:53','',197,'http://imp.loc/?post_type=acf-field&p=198',0,'acf-field','',0),
(199,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"80\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','g','publish','closed','closed','','field_69c12242f16f4','','','2026-03-23 13:23:19','2026-03-23 11:23:19','',197,'http://imp.loc/?post_type=acf-field&#038;p=199',1,'acf-field','',0),
(200,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','ПІБ','name','publish','closed','closed','','field_69c12252f16f5','','','2026-03-23 13:22:53','2026-03-23 11:22:53','',199,'http://imp.loc/?post_type=acf-field&p=200',0,'acf-field','',0),
(201,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Посада','position','publish','closed','closed','','field_69c12264f16f6','','','2026-03-23 13:22:53','2026-03-23 11:22:53','',199,'http://imp.loc/?post_type=acf-field&p=201',1,'acf-field','',0),
(202,1,'2026-03-23 13:22:53','2026-03-23 11:22:53','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"tabs\";s:6:\"visual\";s:7:\"toolbar\";s:5:\"basic\";s:12:\"media_upload\";i:0;s:5:\"delay\";i:1;}','Опис','content','publish','closed','closed','','field_69c12274f16f7','','','2026-03-23 13:24:53','2026-03-23 11:24:53','',199,'http://imp.loc/?post_type=acf-field&#038;p=202',2,'acf-field','',0),
(203,1,'2026-03-23 13:28:44','2026-03-23 11:28:44','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";b:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Місія/Цінності','_копіювати','publish','closed','closed','','field_69c123630c522','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',172,'http://imp.loc/?post_type=acf-field&#038;p=203',2,'acf-field','',0),
(204,1,'2026-03-23 13:28:44','2026-03-23 11:28:44','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','mission-section','publish','closed','closed','','field_69c1237e0c523','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',172,'http://imp.loc/?post_type=acf-field&#038;p=204',3,'acf-field','',0),
(205,1,'2026-03-23 13:28:44','2026-03-23 11:28:44','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_69c1237e0c524','','','2026-03-23 13:31:11','2026-03-23 11:31:11','',204,'http://imp.loc/?post_type=acf-field&#038;p=205',0,'acf-field','',0),
(206,1,'2026-03-23 13:28:44','2026-03-23 11:28:44','a:13:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"pagination\";i:0;s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:9:\"collapsed\";s:0:\"\";s:12:\"button_label\";s:23:\"Додати рядок\";s:13:\"rows_per_page\";i:20;}','','items','publish','closed','closed','','field_69c123990c526','','','2026-03-23 13:30:14','2026-03-23 11:30:14','',204,'http://imp.loc/?post_type=acf-field&#038;p=206',1,'acf-field','',0),
(207,1,'2026-03-23 13:28:44','2026-03-23 11:28:44','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_69c123ac0c527','','','2026-03-23 13:31:11','2026-03-23 11:31:11','',206,'http://imp.loc/?post_type=acf-field&#038;p=207',0,'acf-field','',0),
(208,1,'2026-03-23 13:28:44','2026-03-23 11:28:44','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"tabs\";s:6:\"visual\";s:7:\"toolbar\";s:5:\"basic\";s:12:\"media_upload\";i:0;s:5:\"delay\";i:1;}','Контент','content','publish','closed','closed','','field_69c123c60c528','','','2026-03-23 13:31:11','2026-03-23 11:31:11','',206,'http://imp.loc/?post_type=acf-field&#038;p=208',1,'acf-field','',0),
(209,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";b:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Принципи','_копіювати','publish','closed','closed','','field_69c124cde1287','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',172,'http://imp.loc/?post_type=acf-field&#038;p=209',4,'acf-field','',0),
(210,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','principles-section','publish','closed','closed','','field_69c124dde1288','','','2026-03-23 14:56:00','2026-03-23 12:56:00','',172,'http://imp.loc/?post_type=acf-field&#038;p=210',5,'acf-field','',0),
(211,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_69c124dde1289','','','2026-03-23 13:35:05','2026-03-23 11:35:05','',210,'http://imp.loc/?post_type=acf-field&p=211',0,'acf-field','',0),
(212,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:13:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"table\";s:10:\"pagination\";i:0;s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:9:\"collapsed\";s:0:\"\";s:12:\"button_label\";s:23:\"Додати рядок\";s:13:\"rows_per_page\";i:20;}','','items','publish','closed','closed','','field_69c124dde128a','','','2026-03-23 13:35:24','2026-03-23 11:35:24','',210,'http://imp.loc/?post_type=acf-field&#038;p=212',1,'acf-field','',0),
(213,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:17:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"21\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:12:\"preview_size\";s:9:\"thumbnail\";}','Зображення','image','publish','closed','closed','','field_69c12502e128d','','','2026-03-23 13:35:05','2026-03-23 11:35:05','',212,'http://imp.loc/?post_type=acf-field&p=213',0,'acf-field','',0),
(214,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"80\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','g','publish','closed','closed','','field_69c1251ee128e','','','2026-03-23 13:35:05','2026-03-23 11:35:05','',212,'http://imp.loc/?post_type=acf-field&p=214',1,'acf-field','',0),
(215,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_69c12525e128f','','','2026-03-23 13:35:05','2026-03-23 11:35:05','',214,'http://imp.loc/?post_type=acf-field&p=215',0,'acf-field','',0),
(216,1,'2026-03-23 13:35:05','2026-03-23 11:35:05','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:3;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','Контент','content','publish','closed','closed','','field_69c12541e1290','','','2026-03-23 13:35:05','2026-03-23 11:35:05','',214,'http://imp.loc/?post_type=acf-field&p=216',1,'acf-field','',0),
(217,1,'2026-03-23 13:48:20','2026-03-23 11:48:20','','partner','','inherit','closed','closed','','partner','','','2026-03-23 13:48:20','2026-03-23 11:48:20','',10,'http://imp.loc/wp-content/uploads/2026/03/partner.webp',0,'attachment','image/webp',0),
(218,1,'2026-03-23 14:58:24','2026-03-23 12:58:24','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"post_template\";s:8:\"operator\";s:2:\"!=\";s:5:\"value\";s:14:\"front-page.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Уривок','uryvok','publish','closed','closed','','group_69c13892548ed','','','2026-03-23 15:12:39','2026-03-23 13:12:39','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=218',0,'acf-field-group','',0),
(219,1,'2026-03-23 14:58:24','2026-03-23 12:58:24','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:2;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','','page-description','publish','closed','closed','','field_69c138924d7a7','','','2026-03-23 15:12:39','2026-03-23 13:12:39','',218,'http://imp.loc/?post_type=acf-field&#038;p=219',0,'acf-field','',0),
(220,1,'2026-03-23 15:13:00','2026-03-23 13:13:00','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:18:\"page-documents.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Page | Documents','page-documents','publish','closed','closed','','group_69c13c5c254a3','','','2026-03-23 16:13:14','2026-03-23 14:13:14','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=220',0,'acf-field-group','',0),
(221,1,'2026-03-23 15:13:00','2026-03-23 13:13:00','a:7:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";}','','page_content','publish','closed','closed','','field_69c13c5c268c7','','','2026-03-23 15:13:00','2026-03-23 13:13:00','',220,'http://imp.loc/?post_type=acf-field&#038;p=221',0,'acf-field','',0),
(230,1,'2026-03-23 15:13:00','2026-03-23 13:13:00','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"tabs\";s:6:\"visual\";s:7:\"toolbar\";s:5:\"basic\";s:12:\"media_upload\";i:0;s:5:\"delay\";i:0;}','Застереження','info','publish','closed','closed','','field_69c13c5c35346','','','2026-03-23 16:13:14','2026-03-23 14:13:14','',221,'http://imp.loc/?post_type=acf-field&#038;p=230',0,'acf-field','',0),
(251,1,'2026-03-23 15:30:59','0000-00-00 00:00:00','','Авточернетка','','auto-draft','closed','closed','','','','','2026-03-23 15:30:59','0000-00-00 00:00:00','',0,'http://imp.loc/?post_type=documents&p=251',0,'documents','',0),
(252,1,'2026-03-23 15:31:19','0000-00-00 00:00:00','','Авточернетка','','auto-draft','closed','closed','','','','','2026-03-23 15:31:19','0000-00-00 00:00:00','',0,'http://imp.loc/?post_type=documents&p=252',0,'documents','',0),
(253,1,'2026-03-23 15:31:30','0000-00-00 00:00:00','','Авточернетка','','auto-draft','closed','closed','','','','','2026-03-23 15:31:30','0000-00-00 00:00:00','',0,'http://imp.loc/?post_type=documents&p=253',0,'documents','',0),
(254,1,'2026-03-23 15:31:36','0000-00-00 00:00:00','','Авточернетка','','auto-draft','closed','closed','','','','','2026-03-23 15:31:36','0000-00-00 00:00:00','',0,'http://imp.loc/?post_type=documents&p=254',0,'documents','',0),
(255,1,'2026-03-23 15:34:05','2026-03-23 13:34:05','','Шаблон договору про надання послуг','','publish','closed','closed','','shablon-dogovoru-pro-nadannya-poslug','','','2026-03-23 15:59:18','2026-03-23 13:59:18','',0,'http://imp.loc/?post_type=documents&#038;p=255',0,'documents','',0),
(256,1,'2026-03-23 15:41:35','2026-03-23 13:41:35','a:9:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:9:\"documents\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";s:12:\"show_in_rest\";i:0;s:13:\"display_title\";s:0:\"\";}','Інформація про документ','informacziya-pro-dokument','publish','closed','closed','','group_69c1427be97ce','','','2026-03-23 16:02:25','2026-03-23 14:02:25','',0,'http://imp.loc/?post_type=acf-field-group&#038;p=256',0,'acf-field-group','',0),
(257,1,'2026-03-23 15:41:35','2026-03-23 13:41:35','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','document-data','publish','closed','closed','','field_69c1427ce21ea','','','2026-03-23 15:41:35','2026-03-23 13:41:35','',256,'http://imp.loc/?post_type=acf-field&p=257',0,'acf-field','',0),
(258,1,'2026-03-23 15:41:35','2026-03-23 13:41:35','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"file\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"20\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:7:\"library\";s:3:\"all\";s:8:\"min_size\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;}','Файл','file','publish','closed','closed','','field_69c142abe21eb','','','2026-03-23 16:02:25','2026-03-23 14:02:25','',257,'http://imp.loc/?post_type=acf-field&#038;p=258',0,'acf-field','',0),
(259,1,'2026-03-23 15:41:35','2026-03-23 13:41:35','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:2:\"80\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','g','publish','closed','closed','','field_69c142e7e21ed','','','2026-03-23 15:42:12','2026-03-23 13:42:12','',257,'http://imp.loc/?post_type=acf-field&#038;p=259',1,'acf-field','',0),
(260,1,'2026-03-23 15:41:35','2026-03-23 13:41:35','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Тег','tag','publish','closed','closed','','field_69c142d2e21ec','','','2026-03-23 15:41:35','2026-03-23 13:41:35','',259,'http://imp.loc/?post_type=acf-field&p=260',0,'acf-field','',0),
(261,1,'2026-03-23 15:41:35','2026-03-23 13:41:35','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:3;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','Опис','description','publish','closed','closed','','field_69c142f7e21ee','','','2026-03-23 15:41:35','2026-03-23 13:41:35','',259,'http://imp.loc/?post_type=acf-field&p=261',1,'acf-field','',0),
(262,1,'2026-03-23 15:58:46','2026-03-23 13:58:46','','шаблон','','inherit','closed','closed','','shablon_dogovoru_pro_nadannya_poslug','','','2026-03-23 15:59:06','2026-03-23 13:59:06','',255,'http://imp.loc/wp-content/uploads/2026/03/shablon_dogovoru_pro_nadannya_poslug.pdf',0,'attachment','application/pdf',0),
(263,1,'2026-03-23 16:34:31','2026-03-23 14:34:31','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";b:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Консультація','konsultacziya','publish','closed','closed','','field_69c14f6391cf2','','','2026-03-23 16:36:45','2026-03-23 14:36:45','',119,'http://imp.loc/?post_type=acf-field&#038;p=263',2,'acf-field','',0),
(264,1,'2026-03-23 16:36:45','2026-03-23 14:36:45','a:9:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";b:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;s:8:\"selected\";i:0;}','Контакти','_копіювати','publish','closed','closed','','field_69c14f81e9741','','','2026-03-23 16:36:45','2026-03-23 14:36:45','',119,'http://imp.loc/?post_type=acf-field&p=264',0,'acf-field','',0),
(265,1,'2026-03-23 16:36:45','2026-03-23 14:36:45','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}','','consultation','publish','closed','closed','','field_69c14f92e9742','','','2026-03-23 16:36:45','2026-03-23 14:36:45','',119,'http://imp.loc/?post_type=acf-field&p=265',3,'acf-field','',0),
(266,1,'2026-03-23 16:36:45','2026-03-23 14:36:45','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";}','Назва','title','publish','closed','closed','','field_69c14fb9e9743','','','2026-03-23 16:36:45','2026-03-23 14:36:45','',265,'http://imp.loc/?post_type=acf-field&p=266',0,'acf-field','',0),
(267,1,'2026-03-23 16:36:45','2026-03-23 14:36:45','a:12:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"allow_in_bindings\";i:0;s:4:\"rows\";i:3;s:11:\"placeholder\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}','Опис','subtitle','publish','closed','closed','','field_69c14fc6e9744','','','2026-03-23 16:39:42','2026-03-23 14:39:42','',265,'http://imp.loc/?post_type=acf-field&#038;p=267',1,'acf-field','',0),
(268,1,'2026-03-23 16:36:45','2026-03-23 14:36:45','a:8:{s:10:\"aria-label\";s:0:\"\";s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:17:\"allow_in_bindings\";i:0;}','Лінк','link','publish','closed','closed','','field_69c14fd6e9745','','','2026-03-23 16:37:34','2026-03-23 14:37:34','',265,'http://imp.loc/?post_type=acf-field&#038;p=268',2,'acf-field','',0);
/*!40000 ALTER TABLE `bb_posts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_term_relationships`
--

DROP TABLE IF EXISTS `bb_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_term_relationships`
--

LOCK TABLES `bb_term_relationships` WRITE;
/*!40000 ALTER TABLE `bb_term_relationships` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_term_relationships` VALUES
(1,1,0),
(5,1,0),
(6,1,0),
(17,2,0),
(18,2,0),
(19,2,0),
(20,2,0),
(21,2,0),
(22,2,0),
(23,2,0),
(90,3,0),
(91,3,0),
(92,3,0),
(93,3,0),
(94,3,0),
(95,3,0),
(96,3,0),
(97,3,0),
(147,1,0),
(147,4,0),
(153,5,0);
/*!40000 ALTER TABLE `bb_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_term_taxonomy`
--

DROP TABLE IF EXISTS `bb_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_term_taxonomy`
--

LOCK TABLES `bb_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `bb_term_taxonomy` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_term_taxonomy` VALUES
(1,1,'category','',0,1),
(2,2,'nav_menu','',0,7),
(3,3,'nav_menu','',0,8),
(4,4,'blog_category','',0,1),
(5,5,'blog_category','',0,1),
(6,6,'сategories','',0,0),
(7,7,'categories','',0,0);
/*!40000 ALTER TABLE `bb_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_termmeta`
--

DROP TABLE IF EXISTS `bb_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_termmeta`
--

LOCK TABLES `bb_termmeta` WRITE;
/*!40000 ALTER TABLE `bb_termmeta` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bb_termmeta` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_terms`
--

DROP TABLE IF EXISTS `bb_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  `term_order` int(4) DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_terms`
--

LOCK TABLES `bb_terms` WRITE;
/*!40000 ALTER TABLE `bb_terms` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_terms` VALUES
(1,'Uncategorized','uncategorized',0,0),
(2,'Header menu','header-menu',0,0),
(3,'Footer menu','footer-menu',0,0),
(4,'Договора','dogovora',0,0),
(5,'Новини','news',0,0),
(6,'Dogovora','dogovora',0,0),
(7,'NEws','news',0,0);
/*!40000 ALTER TABLE `bb_terms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_usermeta`
--

DROP TABLE IF EXISTS `bb_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_usermeta`
--

LOCK TABLES `bb_usermeta` WRITE;
/*!40000 ALTER TABLE `bb_usermeta` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_usermeta` VALUES
(1,1,'nickname','developerAdmin'),
(2,1,'first_name',''),
(3,1,'last_name',''),
(4,1,'description',''),
(5,1,'rich_editing','true'),
(6,1,'syntax_highlighting','true'),
(7,1,'comment_shortcuts','false'),
(8,1,'admin_color','fresh'),
(9,1,'use_ssl','0'),
(10,1,'show_admin_bar_front','true'),
(11,1,'locale',''),
(12,1,'bb_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
(13,1,'bb_user_level','10'),
(14,1,'dismissed_wp_pointers',''),
(15,1,'show_welcome_panel','0'),
(16,1,'session_tokens','a:13:{s:64:\"64784f25c1809e3b04348cc9d32ce981589e893de8acc243a9585598612fb4a7\";a:4:{s:10:\"expiration\";i:1774429617;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774256817;}s:64:\"5d7025e0469a1322ff6d39d8fbefced9c1bfc458da0cd0f6cea6d4acf539bf29\";a:4:{s:10:\"expiration\";i:1774431705;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774258905;}s:64:\"811bb84e50bef7c37d56279e9e2d78f8b54fcbde40de89919dc7c8b492e5f5a4\";a:4:{s:10:\"expiration\";i:1774434724;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774261924;}s:64:\"7efb82b344a7c9873e0b6aa70865bdd7966a1517d7c68c2b7c7273c41492b8d9\";a:4:{s:10:\"expiration\";i:1774437343;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774264543;}s:64:\"1e326500fa755e8ef4b3903e073d813fb1d8bf6f7cc331657299e4aa229994e1\";a:4:{s:10:\"expiration\";i:1774440933;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774268133;}s:64:\"8d77dd3fb0511e5cb196c49567304910056d5c3844de8f27757039e0eae8d409\";a:4:{s:10:\"expiration\";i:1774444538;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774271738;}s:64:\"db2ed172ffcedb28354bee62a65c9c1a2f0a04739388208e58a3eb2505b9cfea\";a:4:{s:10:\"expiration\";i:1774448134;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774275334;}s:64:\"07c09cd6772f6f5cf5cf5134ed7eabd433fb7bc6b4aa6d1fc3cbfa988692d257\";a:4:{s:10:\"expiration\";i:1774452578;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774279778;}s:64:\"5bde3a29bb9286ced213c247ebe92a9c9bea990edce3e54b82506032d3f59cc7\";a:4:{s:10:\"expiration\";i:1774455551;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774282751;}s:64:\"ba26a8f29751055466f7b7938a0845ef1775264b823aab1bf90565fb30564722\";a:4:{s:10:\"expiration\";i:1774458956;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774286156;}s:64:\"1da10f093fdb117970704becb540222656b1cb50b1e55a79df37baaffcd92ad9\";a:4:{s:10:\"expiration\";i:1774464832;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774292032;}s:64:\"bd7736624be29474aa61e2ac44c5f075f1e8b51086810953062c010f068e2d3e\";a:4:{s:10:\"expiration\";i:1774552663;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36\";s:5:\"login\";i:1774379863;}s:64:\"2925af2b47123db26ff810424eee5aafe93b1c6dc7dd056452af83c867b47777\";a:4:{s:10:\"expiration\";i:1774552663;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:31:\"WordPress/6.9.4; http://imp.loc\";s:5:\"login\";i:1774379863;}}'),
(17,1,'default_password_nag',''),
(18,1,'bb_persisted_preferences','a:3:{s:4:\"core\";a:6:{s:26:\"isComplementaryAreaVisible\";b:1;s:10:\"editorMode\";s:6:\"visual\";s:15:\"distractionFree\";b:0;s:12:\"fixedToolbar\";b:0;s:9:\"focusMode\";b:0;s:10:\"openPanels\";a:5:{i:0;s:11:\"post-status\";i:1;s:27:\"taxonomy-panel-articles_tag\";i:2;s:32:\"taxonomy-panel-articles_category\";i:3;s:28:\"taxonomy-panel-blog_category\";i:4;s:23:\"taxonomy-panel-category\";}}s:14:\"core/edit-post\";a:4:{s:12:\"welcomeGuide\";b:0;s:19:\"metaBoxesMainIsOpen\";b:1;s:23:\"metaBoxesMainOpenHeight\";i:318;s:14:\"fullscreenMode\";b:0;}s:9:\"_modified\";s:24:\"2026-03-22T14:22:20.788Z\";}'),
(19,1,'managenav-menuscolumnshidden','a:4:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}'),
(20,1,'metaboxhidden_nav-menus','a:3:{i:0;s:18:\"add-post-type-blog\";i:1;s:12:\"add-post_tag\";i:2;s:17:\"add-blog_category\";}'),
(21,1,'manageedit-servicescolumnshidden','a:0:{}'),
(22,1,'bb_user-settings','libraryContent=browse&posts_list_mode=list&editor=tinymce'),
(23,1,'bb_user-settings-time','1774190297'),
(24,1,'edit_blog_per_page','20'),
(25,1,'meta-box-order_page','a:4:{s:15:\"acf_after_title\";s:23:\"acf-group_69c13892548ed\";s:4:\"side\";s:36:\"submitdiv,postimagediv,pageparentdiv\";s:6:\"normal\";s:17:\"slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
(26,1,'screen_layout_page','2'),
(27,1,'closedpostboxes_page','a:0:{}'),
(28,1,'metaboxhidden_page','a:2:{i:0;s:7:\"slugdiv\";i:1;s:9:\"authordiv\";}'),
(29,1,'wpcf7_hide_welcome_panel_on','a:1:{i:0;s:3:\"6.1\";}'),
(30,1,'nav_menu_recently_edited','3'),
(31,1,'meta-box-order_services','a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:34:\"submitdiv,postexcerpt,postimagediv\";s:6:\"normal\";s:31:\"acf-group_69bffb5025fe8,slugdiv\";s:8:\"advanced\";s:0:\"\";}'),
(32,1,'screen_layout_services','2'),
(33,1,'closedpostboxes_services','a:0:{}'),
(34,1,'metaboxhidden_services','a:1:{i:0;s:7:\"slugdiv\";}');
/*!40000 ALTER TABLE `bb_usermeta` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `bb_users`
--

DROP TABLE IF EXISTS `bb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bb_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bb_users`
--

LOCK TABLES `bb_users` WRITE;
/*!40000 ALTER TABLE `bb_users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `bb_users` VALUES
(1,'developerAdmin','$wp$2y$10$tLTujnlImM3V5vpWyVJPjeK1wK.5qwV3JEh/O5xTAzRcow1Uj2Qti','developeradmin','romecom2210@gmail.com','http://imp.loc','2026-03-16 17:15:30','',0,'developerAdmin');
/*!40000 ALTER TABLE `bb_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'imp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-25 11:37:35
